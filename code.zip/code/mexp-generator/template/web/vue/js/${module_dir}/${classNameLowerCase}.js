<#assign className = table.className>
<#assign classNameLower = className?uncap_first>
<#assign classNameLowerCase = className?lower_case>
import request from '@/utils/request'

const path = '/${classNameLowerCase}'
// 获取列表(不分页)
export function findList(query) {
  return request({
    url: <#noparse>`${path}/v1/findList`</#noparse>,
    method: 'post',
    data: query
  })
}
// 获取列表(分页)
export function findPage(query) {
  return request({
    url: <#noparse>`${path}/v1/findPage`</#noparse>,
    method: 'POST',
    data: query
  })
}
// 获取详细
export function input(query) {
  return request({
    url: <#noparse>`${path}/v1/input`</#noparse>,
    method: 'POST',
    data: query
  })
}
// 删除
export function remove(query) {
  return request({
    url: <#noparse>`${path}/v1/delete`</#noparse>,
    method: 'POST',
    data: query
  })
}
// 保存
export function save(query) {
  return request({
    url: <#noparse>`${path}/v1/save`</#noparse>,
    method: 'POST',
    data: query
  })
}
