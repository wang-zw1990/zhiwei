<#assign className = table.className>
<#assign classNameLower = className?uncap_first>
<#assign classNameLowerCase = className?lower_case>
<template>
  <div class="container">
    <el-breadcrumb separator-class="el-icon-arrow-right">
      <i class="el-icon-position" />
      <el-breadcrumb-item>XXXXXX</el-breadcrumb-item>
      <el-breadcrumb-item>${table.tableAlias}管理</el-breadcrumb-item>
    </el-breadcrumb>
    <el-card shadow="never">
      <el-input v-model="query['${classNameLower}Query']" placeholder="请输入关键字" clearable />
      <el-button type="primary" icon="el-icon-search" @click="findPage">搜索</el-button>
      <el-button icon="el-icon-refresh" @click="reset">重置</el-button>
    </el-card>
    <el-table v-loading="tableLoading" :data="tableData.result" :header-row-style="headerRowStyle" @sort-change="tableSort" @select="handleRowChange" @select-all="handleRowChange">
      <el-table-column type="selection" width="45" />
      <#list table.columns as column>
      <el-table-column sortable="custom" prop="${column.columnNameLower}" label="${column.columnAlias!}" align="center" min-width="150" :show-overflow-tooltip="$store.state.settings.showOverflow" />
      </#list>
      <el-table-column label="操作" align="center" min-width="190">
        <template slot-scope="scope">
          <el-button type="primary" icon="el-icon-edit-outline" size="mini" @click="selectRow=scope.row ,getDataById()">编辑</el-button>
          <el-button type="danger" icon="el-icon-delete" size="mini" @click="multipleSelection=[scope.row],remove()">删除</el-button>
        </template>
      </el-table-column>
    </el-table>
    <el-card shadow="never">
      <el-button icon="el-icon-plus" type="primary" class="fl" @click="selectRow=null,getDataById()">新增</el-button>
      <el-button icon="el-icon-delete" type="danger" class="fl" @click="remove()">删除</el-button>
    </el-card>
    <div class="pagination">
      <span class="showinfo">
        显示 {{ tableData.currentFirst }} 到 {{ tableData.currentLast }}条，
      </span>
      <el-pagination
              background
              layout="total, sizes, prev, pager, next"
              :page-size="query['page.pageSize']"
              :total="tableData.totalCount"
              :page-sizes="[10, 25, 50, 100]"
              :current-page="query['page.pageNo']"
              @size-change="handleSizeChange"
              @current-change="handleCurrentChange"
      />
    </div>
    <!--设置${table.tableAlias}信息-->
    <el-dialog title="设置${table.tableAlias}信息" :visible.sync="dialogVisible" width="800px" top="5vh" :close-on-click-modal="false">
      <el-form ref="formData" :model="formData" :rules="rules" label-position="right" label-width="100px" size="medium">
        <#list table.columns as column>
        <el-form-item label="${column.columnAlias!}" class="w50p fl" prop="${column.columnNameLower}">
          <el-input v-model="formData.${column.columnNameLower}" placeholder="${column.columnAlias!}" />
        </el-form-item>
        </#list>
        <div class="clear" />
      </el-form>
      <div slot="footer" class="dialog-footer">
        <el-button @click="dialogVisible = false">取消</el-button>
        <el-button type="primary" @click="submit()">保存</el-button>
      </div>
    </el-dialog>
  </div>
</template>

<script>
import * as ${classNameLowerCase} from '@/api/xxxxxx/${classNameLowerCase}'
export default {
  name: '${classNameLowerCase}',
  data() {
    return {
      query: {
        'page.pageNo': 1,
        'page.pageSize': 10,
        'page.orderBy': '',id
        'page.order': 'desc',
        '${classNameLower}Query.nameLike': ''
      },
      selectRow: null,
      tableLoading: false,
      multipleSelection: [],
      tableData: {
        result: null,
        totalCount: 0,
        currentFirst: 0,
        currentLast: 0
      },
      rules: {
        <#list table.columns as column>
        ${column.columnNameLower}: [{ required: true, message: '请填写${column.columnAlias!}', trigger: 'blur' }],
        </#list>
        name: [{ required: true, message: '请填写角色名称', trigger: 'blur' }]
      },
      dialogVisible: false,
      formData: {
        <#list table.columns as column>
        ${column.columnNameLower}: '',
        </#list>
      }
    }
  },
  created() {
    this.findPage()
  },
  methods: {
    headerRowStyle() {
      return { color: this.$store.state.settings.theme }
    },
    reset() {
      this.query['${classNameLower}Query.nameLike'] = ''
      this.query['page.pageNo'] = 1
      this.query['page.pageSize'] = 10
      this.findPage()
    },
    handleCurrentChange(val) {
      this.query['page.pageNo'] = val
      this.findPage()
    },
    handleSizeChange(val) {
      this.query['page.pageSize'] = val
      this.findPage()
    },
    tableSort(obj) {id
      obj.prop = this.changeWord(obj.prop)
      this.query['page.orderBy'] = obj.order ? obj.prop : ''
      this.query['page.order'] = obj.order ? obj.order.replace('ending', '') : 'desc'
      this.findPage()
    },
    changeWord(prop) {
      if (prop === 'createTimeString') {
        prop = 'CREATETIME'
      } else if (prop === 'updateTimeString') {
        prop = 'UPDATETIME'
      }
      return prop
    },
    // 当选择时
    handleRowChange(val) {
      this.multipleSelection = val
    },
    findPage() {
      this.tableLoading = true
      ${classNameLowerCase}.findPage(this.query).then(response => {
        this.tableLoading = false
        if (response.data.r_code === 0) {
          this.tableData = response.data.r_data
          this.tableData.currentFirst = this.tableData.currentLast === 0 ? 0 : this.tableData.currentFirst
        } else {
          this.$notify({ message: response.data.r_info, type: 'error', duration: 2000 })
        }
      })
    },
    getDataById() {
      this.dialogVisible = true
      if (this.$refs.formData !== undefined) {
        this.$refs.formData.resetFields()
      }
      if (this.selectRow) {
        const loading = this.$loading({ lock: true, text: '处理中', spinner: 'el-icon-loading', background: 'rgba(0, 0, 0, 0.5)' })
        ${classNameLowerCase}.input({ id: this.selectRow.id }).then(response => {
          loading.close()
          if (response.data.r_code === 0) {
            this.formData = response.data.r_data
          } else {
            this.$notify({ message: response.data.r_info, type: 'error', duration: 2000 })
          }
        })
      } else {
        this.$set(this.formData, 'id', '')
      }
    },
    submit() {
      this.$refs['formData'].validate((valid) => {
        if (valid) {
          var param = {}
          <#list table.columns as column>
          param['${classNameLower}.${column.columnNameLower}'] = this.formData.${column.columnNameLower}
          </#list>
          const loading = this.$loading({ lock: true, text: '处理中', spinner: 'el-icon-loading', background: 'rgba(0, 0, 0, 0.5)' })
          ${classNameLowerCase}.save(param).then(response => {
            loading.close()
            if (response.data.r_code === 0) {
              this.$notify({ message: response.data.r_info, type: 'success', duration: 2000 })
              this.dialogVisible = false
              this.findPage()
            } else {
              this.$notify({ message: response.data.r_info, type: 'error', duration: 2000 })
            }
          })
        }
      })
    },
    remove() {
      if (this.multipleSelection.length === 0) {
        this.$message({ message: '请选择删除的记录', type: 'warning', duration: 2000 })
        return
      }
      this.$confirm('确认删除记录？', '提示', {
        confirmButtonText: '确定',
        cancelButtonText: '取消',
        type: 'warning'
      }).then(() => {
        var params = {}
        this.multipleSelection.forEach((item, i) => {
          params['checkedIdList[' + i + ']'] = item.id
        })
        const loading = this.$loading({ lock: true, text: '处理中', spinner: 'el-icon-loading', background: 'rgba(0, 0, 0, 0.5)' })
        ${classNameLowerCase}.remove(params).then(response => {
          loading.close()
          this.multipleSelection = []
          if (response.data.r_code === 0) {
            this.$notify({ message: response.data.r_info, type: 'success', duration: 2000 })
            this.findPage()
          } else {
            this.$notify({ message: response.data.r_info, type: 'error', duration: 2000 })
          }
        })
      }).catch(() => {
        this.multipleSelection = []
      })
    }
  }
}
</script>
