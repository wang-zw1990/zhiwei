<#assign className = table.className>   
<#assign classNameLower = className?uncap_first>
<#if module != "" >
package ${basepackage}.${projectpackage}.${module}.query;
<#else>
package ${basepackage}.${projectpackage}.query;
</#if>

import ${basepackage}.${projectpackage}.system.query.BaseQuery;
import org.apache.commons.lang.builder.ToStringBuilder;
import org.apache.commons.lang.builder.ToStringStyle;

import java.io.Serializable;
import java.math.BigDecimal;

import java.util.List;
import java.util.Date;

<#include "/java_copyright.include">

public class ${className}Query extends BaseQuery implements Serializable {
    <@generateFields/>
    <@generateProperties/>
	public String toString() {
		return ToStringBuilder.reflectionToString(this,ToStringStyle.MULTI_LINE_STYLE);
	}
	
}

<#macro generateFields>

	<#list table.columns as column>
	/** ${column.columnAlias} */
	<#if column.isDateTimeColumn >
	private ${column.javaType} ${column.columnNameLower}Begin;
	private ${column.javaType} ${column.columnNameLower}End;
	<#elseif column.isStringColumn>
	private ${column.javaType} ${column.columnNameLower};
	private ${column.javaType} ${column.columnNameLower}Like;
	private ${column.javaType} ${column.columnNameLower}BeginLike;
	private ${column.javaType} ${column.columnNameLower}EndLike;
	<#elseif column.isNumberColumn>
	private ${column.javaType} ${column.columnNameLower};
	private ${column.javaType} ${column.columnNameLower}NotEq;
	private ${column.javaType} ${column.columnNameLower}GT;
	private ${column.javaType} ${column.columnNameLower}LT;
	
	private ${column.javaType} ${column.columnNameLower}GE;
	private ${column.javaType} ${column.columnNameLower}LE;
	
	private List<${column.javaType}> ${column.columnNameLower}List;
	private List<${column.javaType}> ${column.columnNameLower}NotEqList;
	<#else>
	private ${column.javaType} ${column.columnNameLower};
	</#if>
	</#list>

</#macro>

<#macro generateProperties>
	<#list table.columns as column>
	<#if column.isDateTimeColumn>
	public ${column.javaType} get${column.columnName}Begin() {
		return this.${column.columnNameLower}Begin;
	}
	public void set${column.columnName}Begin(${column.javaType} value) {
		this.${column.columnNameLower}Begin = value;
	}
	public ${column.javaType} get${column.columnName}End() {
		return this.${column.columnNameLower}End;
	}
	public void set${column.columnName}End(${column.javaType} value) {
		this.${column.columnNameLower}End = value;
	}
	
	<#elseif column.isStringColumn>
	public ${column.javaType} get${column.columnName}() {
		return this.${column.columnNameLower};
	}
	public void set${column.columnName}(${column.javaType} value) {
		this.${column.columnNameLower} = value;
	}
	public ${column.javaType} get${column.columnName}Like() {
		return this.${column.columnNameLower}Like;
	}
	public void set${column.columnName}Like(${column.javaType} value) {
		this.${column.columnNameLower}Like = value;
	}
	public ${column.javaType} get${column.columnName}BeginLike() {
		return this.${column.columnNameLower}BeginLike;
	}
	public void set${column.columnName}BeginLike(${column.javaType} value) {
		this.${column.columnNameLower}BeginLike = value;
	}
	public ${column.javaType} get${column.columnName}EndLike() {
		return this.${column.columnNameLower}EndLike;
	}
	public void set${column.columnName}EndLike(${column.javaType} value) {
		this.${column.columnNameLower}EndLike = value;
	}

	<#elseif column.isNumberColumn>
	public ${column.javaType} get${column.columnName}() {
		return this.${column.columnNameLower};
	}
	public void set${column.columnName}(${column.javaType} value) {
		this.${column.columnNameLower} = value;
	}
	public ${column.javaType} get${column.columnName}NotEq() {
		return ${column.columnNameLower}NotEq;
	}
	public void set${column.columnName}NotEq(${column.javaType} value) {
		this.${column.columnNameLower}NotEq = value;
	}
	public ${column.javaType} get${column.columnName}GT() {
		return ${column.columnNameLower}GT;
	}
	public void set${column.columnName}GT(${column.javaType} value) {
		this.${column.columnNameLower}GT = value;
	}
	public ${column.javaType} get${column.columnName}LT() {
		return ${column.columnNameLower}LT;
	}
	public void set${column.columnName}LT(${column.javaType} value) {
		this.${column.columnNameLower}LT = value;
	}
	public ${column.javaType} get${column.columnName}GE() {
		return ${column.columnNameLower}GE;
	}
	public void set${column.columnName}GE(${column.javaType} value) {
		this.${column.columnNameLower}GE = value;
	}
	public ${column.javaType} get${column.columnName}LE() {
		return ${column.columnNameLower}LE;
	}
	public void set${column.columnName}LE(${column.javaType} value) {
		this.${column.columnNameLower}LE = value;
	}
	public List<${column.javaType}> get${column.columnName}List() {
		return this.${column.columnNameLower}List;
	}
	public void set${column.columnName}List(List<${column.javaType}> value) {
		this.${column.columnNameLower}List = value;
	}
	public List<${column.javaType}> get${column.columnName}NotEqList() {
		return ${column.columnNameLower}NotEqList;
	}
	public void set${column.columnName}NotEqList(List<${column.javaType}> value) {
		this.${column.columnNameLower}NotEqList = value;
	}

	<#else>
	public ${column.javaType} get${column.columnName}() {
		return this.${column.columnNameLower};
	}
	public void set${column.columnName}(${column.javaType} value) {
		this.${column.columnNameLower} = value;
	}
	
	</#if>	
	</#list>
</#macro>



