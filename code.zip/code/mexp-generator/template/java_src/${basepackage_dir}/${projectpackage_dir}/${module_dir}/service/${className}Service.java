<#assign className = table.className>   
<#assign classNameLower = className?uncap_first>
<#if module != "" >
package ${basepackage}.${projectpackage}.${module}.service;
<#else>
package ${basepackage}.${projectpackage}.service;
</#if>

import ${basepackage}.${projectpackage}.system.exception.ServiceException;
import ${basepackage}.${projectpackage}.system.service.BaseService;
import ${basepackage}.${projectpackage}.system.model.Page;
<#if module != "" >
import ${basepackage}.${projectpackage}.${module}.model.${className};
import ${basepackage}.${projectpackage}.${module}.query.${className}Query;
<#else>
import ${basepackage}.${projectpackage}.model.${className};
import ${basepackage}.${projectpackage}.query.${className}Query;
</#if>

<#include "/java_copyright.include">

public interface ${className}Service extends BaseService<${className}, ${className}Query> {

    /**
     * 分页查询
     * @param page
     * @param query
     * @return
     */
    public Page<${className}> findPage(Page<${className}> page, ${className}Query query) throws ServiceException;

    /**
     * 保存
     * @param entity
     * @throws ServiceException
     */
    public Integer saveOrUpdate(${className} entity) throws ServiceException;

}