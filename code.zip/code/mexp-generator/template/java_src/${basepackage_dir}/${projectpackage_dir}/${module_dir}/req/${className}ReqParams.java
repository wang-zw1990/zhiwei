<#assign className = table.className>   
<#assign classNameLower = className?uncap_first> 
<#assign classNameLowerCase = className?lower_case>
<#if module != "" >
package ${basepackage}.${projectpackage}.${module}.req;
<#else>
package ${basepackage}.${projectpackage}.req;
</#if>

import ${basepackage}.${projectpackage}.system.req.BaseReqParams;
import ${basepackage}.${projectpackage}.system.model.Page;
<#if module != "" >
import ${basepackage}.${projectpackage}.${module}.model.${className};
import ${basepackage}.${projectpackage}.${module}.query.${className}Query;
<#else>
import ${basepackage}.${projectpackage}.model.${className};
import ${basepackage}.${projectpackage}.query.${className}Query;
</#if>

public class ${className}ReqParams extends BaseReqParams
{

    /**
     * serialVersionUID
     */
    private static final long serialVersionUID = 4378148386606781306L;
    
    Page<${className}>  page;
    ${className}        ${classNameLower};
    ${className}Query   ${classNameLower}Query;
    
    public Page<${className}> getPage()
    {
        return page;
    }
    public void setPage(Page<${className}> page)
    {
        this.page = page;
    }
    public ${className} get${className}()
    {
        return ${classNameLower};
    }
    public void set${className}(${className} ${classNameLower})
    {
        this.${classNameLower} = ${classNameLower};
    }
    public ${className}Query get${className}Query()
    {
        return ${classNameLower}Query;
    }
    public void set${className}Query(${className}Query ${classNameLower}Query)
    {
        this.${classNameLower}Query = ${classNameLower}Query;
    }
}
