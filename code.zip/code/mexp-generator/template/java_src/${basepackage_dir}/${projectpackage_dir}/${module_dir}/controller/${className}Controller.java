<#assign className = table.className>   
<#assign classNameLower = className?uncap_first> 
<#assign classNameLowerCase = className?lower_case> 
<#assign idColumnLower = table.idColumn.columnName?uncap_first>
<#if module != "" >
package ${basepackage}.${projectpackage}.${module}.controller;
<#else>
package ${basepackage}.${projectpackage}.controller;
</#if>

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import ${basepackage}.${projectpackage}.ServiceException;
import ${basepackage}.${projectpackage}.system.controller.BaseController;
import ${basepackage}.${projectpackage}.system.model.Page;
<#if module != "" >
import ${basepackage}.${projectpackage}.${module}.model.${className};
import ${basepackage}.${projectpackage}.${module}.query.${className}Query;
import ${basepackage}.${projectpackage}.${module}.req.${className}ReqParams;
import ${basepackage}.${projectpackage}.${module}.service.${className}Service;
<#else>
import ${basepackage}.${projectpackage}.model.${className};
import ${basepackage}.${projectpackage}.query.${className}Query;
import ${basepackage}.${projectpackage}.req.${className}ReqParams;
import ${basepackage}.${projectpackage}.service.${className}Service;
</#if>
import java.util.List;

<#include "/java_copyright.include">

@Slf4j
@Api(tags = "${table.tableAlias}接口")
@RestController
@RequestMapping("/${classNameLowerCase}")
public class ${className}Controller extends BaseController
{
    @Autowired
    private ${className}Service ${classNameLower}Service;

    @ApiOperation(value = "获取分页列表")
    @RequestMapping(value = "/findPage", method = RequestMethod.POST)
    public Object findPage(${className}ReqParams params) throws Exception {
        try { 
            Page<${className}> page = null;
            if(params != null && params.getPage() != null) {
                page = params.getPage();
            }
            if(page == null){
                page = new Page<${className}>();
            }
            if (!page.isOrderBySetted()) {
                page.setOrderBy("id");
                page.setOrder(Page.DESC);               
            }
            
            ${className}Query ${classNameLower}Query = null;
            if(params != null && params.get${className}Query() != null){
                ${classNameLower}Query = params.get${className}Query();
            }
            if(${classNameLower}Query == null) {
                ${classNameLower}Query = new ${className}Query();
            }
            
            page = ${classNameLower}Service.findPage(page, ${classNameLower}Query);
            return responseSuccessJson(page, "检索成功！");
            
        } catch(ServiceException ex) {
            return responseErrorJson(ex.getErrorInfo());
        } catch(Exception e) {
            return responseErrorJson(e.getMessage());
        }
    }

    @ApiOperation(value = "获取列表")
    @RequestMapping(value = "/findList", method = RequestMethod.POST)
    public Object findList(${className}Query query) throws Exception {
        try {
            if(query == null) {
                query = new ${className}Query();
            }
            List<${className}> ${classNameLower}List = ${classNameLower}Service.findList(query);
            return responseSuccessJson(${classNameLower}List, "获取成功！");
        } catch(ServiceException ex) {
            return responseErrorJson(ex.getErrorInfo());
        } catch(Exception e) {
            return responseErrorJson(e.getMessage());
        }
    }

    @ApiOperation(value = "获取单条数据")
    @RequestMapping(value = "/getById", method = RequestMethod.POST)
    public Object getById(java.lang.Integer id) throws Exception {
        try {   
            ${className} ${classNameLower} = null;
            if(id != null){
                ${classNameLower} = ${classNameLower}Service.getById(id);
            }else{
                ${classNameLower} = new ${className}();
            }
            
            return responseSuccessJson(${classNameLower}, "检索成功！");
            
        } catch(ServiceException ex) {
            return responseErrorJson(ex.getErrorInfo());
        } catch(Exception e) {
            return responseErrorJson(e.getMessage());
        }
    }

    @ApiOperation(value = "保存数据")
    @RequestMapping(value = "/save", method = RequestMethod.POST)
    public Object save(${className}ReqParams params) throws Exception {
        try {   
            if(params != null && params.get${className}() != null){
                ${classNameLower}Service.saveOrUpdate(params.get${className}());
            }
            
            return responseSuccessJson(null, "保存成功！");
            
        } catch(ServiceException ex) {
            return responseErrorJson(ex.getErrorInfo());
        } catch(Exception e) {
            return responseErrorJson(e.getMessage());
        }
    }

    @ApiOperation(value = "删除数据")
    @RequestMapping(value = "/remove", method = RequestMethod.POST)
    public Object delete(${className}ReqParams params) throws Exception {
        try {   
            if(params != null && params.getCheckedIdList() != null && params.getCheckedIdList().size() > 0){
                ${classNameLower}Service.deleteByMultipleId(params.getCheckedIdList());
            }
            
            return responseSuccessJson(null, "删除成功！");
            
        } catch(ServiceException ex) {
            return responseErrorJson(ex.getErrorInfo());
        } catch(Exception e) {
            return responseErrorJson(e.getMessage());
        }
    }  
}
