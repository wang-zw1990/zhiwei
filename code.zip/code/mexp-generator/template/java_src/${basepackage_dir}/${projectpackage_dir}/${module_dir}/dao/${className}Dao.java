<#assign className = table.className>   
<#assign classNameLower = className?uncap_first>
<#if module != "" >
package ${basepackage}.${projectpackage}.${module}.dao;
<#else>
package ${basepackage}.${projectpackage}.dao;
</#if>
import org.apache.ibatis.annotations.Mapper;
import ${basepackage}.${projectpackage}.system.dao.BaseDao;

<#if module != "" >
import ${basepackage}.${projectpackage}.${module}.model.${className};
import ${basepackage}.${projectpackage}.${module}.query.${className}Query;
<#else>
import ${basepackage}.${projectpackage}.model.${className};
import ${basepackage}.${projectpackage}.query.${className}Query;
</#if>

<#include "/java_copyright.include">

@Mapper
@Repository
public interface ${className}Dao extends BaseDao<${className}, ${className}Query>{
    //
}