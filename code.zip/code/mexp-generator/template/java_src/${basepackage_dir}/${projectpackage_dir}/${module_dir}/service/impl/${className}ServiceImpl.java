<#assign className = table.className>   
<#assign classNameLower = className?uncap_first>
<#if module != "" >
package ${basepackage}.${projectpackage}.${module}.service.impl;
<#else>
package ${basepackage}.${projectpackage}.service.impl;
</#if>

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.lang.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import ${basepackage}.${projectpackage}.ServiceException;
import ${basepackage}.${projectpackage}.system.service.impl.BaseServiceImpl;
import ${basepackage}.${projectpackage}.system.model.Page;

<#if module != "" >
import ${basepackage}.${projectpackage}.${module}.dao.${className}Dao;
import ${basepackage}.${projectpackage}.${module}.model.${className};
import ${basepackage}.${projectpackage}.${module}.query.${className}Query;
import ${basepackage}.${projectpackage}.${module}.service.${className}Service;
<#else>
import ${basepackage}.${projectpackage}.dao.${className}Dao;
import ${basepackage}.${projectpackage}.model.${className};
import ${basepackage}.${projectpackage}.query.${className}Query;
import ${basepackage}.${projectpackage}.service.${className}Service;
</#if>
<#include "/java_copyright.include">

@Service
public class ${className}ServiceImpl extends BaseServiceImpl<${className}, ${className}Query> implements ${className}Service{

    @Autowired
    private ${className}Dao ${classNameLower}Dao;

    @Override
    public BaseDao getBaseDao(){ return ${classNameLower}Dao; }

    @Override
    public Page<${className}> findPage(Page<${className}> page, ${className}Query query)
    {
        Long totalCount = ${classNameLower}Dao.pageTotalCount(query);
        // 总件数
        page.setTotalCount(totalCount);
        
        if(totalCount == null || totalCount.longValue() <= 0) {
            page.setResult(new ArrayList<${className}>());
            return page;
        }
        
        Map<String, Object> otherFilters = new HashMap<String, Object>();
        otherFilters.put("offset", page.getCurrentFirst() - 1);
        otherFilters.put("pageSize", page.getPageSize());
        otherFilters.put("lastRows", page.getCurrentLast());
        
        StringBuffer  sortColumns = new StringBuffer();
        sortColumns.append(" ");
        if (page.isOrderBySetted()) {
            String[] orderByArray = StringUtils.split(page.getOrderBy(), ',');
            String[] orderArray = StringUtils.split(page.getOrder(), ',');
            
            for (int i = 0; i < orderByArray.length; i++) {
                if(i > 0) {
                    sortColumns.append(" , ");
                }
                String orderBy = orderByArray[i];
                if(orderByArray[i].endsWith("Name")) {
                    orderBy = " CONVERT( " + orderBy + " using gbk)";
                }
                sortColumns.append(orderBy);
                if (Page.ASC.equals(orderArray[i])) {
                    sortColumns.append(" ASC ");
                } else {
                    sortColumns.append(" DESC ");
                }
            }
        }
        if(!" ".equals(sortColumns.toString())) {
            query.setSortColumns(sortColumns.toString());
        }
        
        query.setOffset(page.getCurrentFirst()-1);
        query.setPageSize(page.getPageSize());
        query.setLastRows(page.getCurrentLast());
        
        List<${className}> result = ${classNameLower}Dao.findPage(query);
        page.setResult(result);
                
        return page;
    }

    @Override
    public Integer saveOrUpdate(${className} entity) throws ServiceException {
        if(entity.getId() == null){
            return ${classNameLower}Dao.save(entity);
        } else {
            return ${classNameLower}Dao.update(entity);
        }
    }
}
