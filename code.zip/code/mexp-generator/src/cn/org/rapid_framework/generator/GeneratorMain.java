package cn.org.rapid_framework.generator;


/**
 * 
 * @author badqiu
 * @email badqiu(a)gmail.com
 */

public class GeneratorMain {
	/**
	 * 请直接修改以下代码调用不同的方法以执行相关生成任务.
	 */
	public static void main(String[] args) throws Exception {
		GeneratorFacade g = new GeneratorFacade();
		g.deleteOutRootDir();

		g.generateByTable("bus_left_nav","template");
		g.generateByTable("bus_web","template");
//		g.generateByTable("sys_log","template");
//		g.generateByTable("sys_menu","template");
//		g.generateByTable("sys_role","template");
//		g.generateByTable("sys_user","template");
		
		//打开文件夹
		Runtime.getRuntime().exec("cmd.exe /c start "+GeneratorProperties.getRequiredProperty("outRoot"));
	}
}
