/*
Navicat MySQL Data Transfer

Source Server         : localhost
Source Server Version : 50717
Source Host           : localhost:3306
Source Database       : self_study_web

Target Server Type    : MYSQL
Target Server Version : 50717
File Encoding         : 65001

Date: 2020-12-15 23:29:03
*/

SET FOREIGN_KEY_CHECKS=0;

-- ----------------------------
-- Table structure for sys_log
-- ----------------------------
DROP TABLE IF EXISTS `sys_log`;
CREATE TABLE `sys_log` (
  `id` int(11) NOT NULL AUTO_INCREMENT COMMENT '主键',
  `content` text COMMENT '内容',
  `creator` varchar(20) DEFAULT NULL COMMENT '创建者',
  `creator_id` int(11) DEFAULT NULL COMMENT '创建者id',
  `create_time` timestamp NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='系统日志';

-- ----------------------------
-- Records of sys_log
-- ----------------------------

-- ----------------------------
-- Table structure for sys_menu
-- ----------------------------
DROP TABLE IF EXISTS `sys_menu`;
CREATE TABLE `sys_menu` (
  `id` int(11) NOT NULL AUTO_INCREMENT COMMENT 'ID',
  `parent_id` int(11) NOT NULL COMMENT '父ID',
  `name` varchar(50) CHARACTER SET utf8 DEFAULT NULL COMMENT '功能名称',
  `css` varchar(255) CHARACTER SET utf8 DEFAULT NULL COMMENT '样式',
  `path` varchar(1000) CHARACTER SET utf8 DEFAULT NULL COMMENT '路由',
  `permission` varchar(50) CHARACTER SET utf8 DEFAULT NULL COMMENT '权限',
  `type` varchar(10) CHARACTER SET utf8 DEFAULT NULL COMMENT '类别',
  `sort` int(11) DEFAULT NULL COMMENT '排序',
  `creator` varchar(20) CHARACTER SET utf8 DEFAULT NULL COMMENT '创建者',
  `creator_id` int(11) DEFAULT NULL COMMENT '创建者id',
  `create_time` timestamp NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  `modify_time` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '最后更新时间',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=161 DEFAULT CHARSET=utf8mb4 ROW_FORMAT=COMPACT COMMENT='权限定义表';

-- ----------------------------
-- Records of sys_menu
-- ----------------------------
INSERT INTO `sys_menu` VALUES ('100', '0', '系统管理', 'fa-cog', 'system', '', 'system', '1090000', null, null, '2020-08-06 14:22:39', '2020-10-30 22:47:44');
INSERT INTO `sys_menu` VALUES ('110', '100', '菜单管理', 'fa-cog', 'menu', '', 'system', '1090010', null, null, '2020-08-06 14:22:39', '2020-10-30 22:47:46');
INSERT INTO `sys_menu` VALUES ('120', '100', '角色管理', 'fa-cog', 'role', '', 'system', '1090030', null, null, '2020-08-06 14:22:39', '2020-10-30 22:47:46');
INSERT INTO `sys_menu` VALUES ('130', '100', '用户管理', 'fa-cog', 'user', '', 'system', '1090040', null, null, '2020-08-06 14:22:39', '2020-10-30 22:47:46');
INSERT INTO `sys_menu` VALUES ('140', '100', '日志管理', 'fa-cog', 'log', '', 'system', '1090060', null, null, '2020-08-06 14:22:39', '2020-10-30 22:47:46');
INSERT INTO `sys_menu` VALUES ('150', '100', '桌面菜单', null, 'desktopmenu', null, 'desktop', null, null, null, '2020-11-03 00:32:24', '2020-11-03 00:32:50');
INSERT INTO `sys_menu` VALUES ('160', '100', '代码生成', null, 'generator', null, 'system', null, null, null, '2020-11-05 11:42:42', '2020-11-05 11:43:20');

-- ----------------------------
-- Table structure for sys_role
-- ----------------------------
DROP TABLE IF EXISTS `sys_role`;
CREATE TABLE `sys_role` (
  `id` int(11) NOT NULL AUTO_INCREMENT COMMENT 'ID',
  `name` varchar(50) CHARACTER SET utf8 DEFAULT NULL COMMENT '角色名称',
  `description` varchar(100) CHARACTER SET utf8 DEFAULT NULL COMMENT '描述',
  `creator` varchar(20) CHARACTER SET utf8 DEFAULT NULL COMMENT '创建者',
  `creator_id` int(11) DEFAULT NULL COMMENT '创建者id',
  `create_time` timestamp NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  `modify_time` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '最后更新时间',
  PRIMARY KEY (`id`) USING BTREE,
  UNIQUE KEY `name` (`name`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 ROW_FORMAT=COMPACT COMMENT='角色定义表';

-- ----------------------------
-- Records of sys_role
-- ----------------------------
INSERT INTO `sys_role` VALUES ('1', '超级管理员', '超级管理员', null, null, '2020-08-06 14:18:09', '2020-08-06 14:18:09');
INSERT INTO `sys_role` VALUES ('2', '管理员', '管理员', null, null, '2020-08-06 14:18:09', '2020-10-29 19:56:05');
INSERT INTO `sys_role` VALUES ('3', '34', null, null, null, '2020-11-03 00:38:51', '2020-11-03 00:38:51');

-- ----------------------------
-- Table structure for sys_role_menu
-- ----------------------------
DROP TABLE IF EXISTS `sys_role_menu`;
CREATE TABLE `sys_role_menu` (
  `role_id` int(11) NOT NULL COMMENT '角色ID',
  `menu_id` int(11) NOT NULL COMMENT '权限ID',
  PRIMARY KEY (`role_id`,`menu_id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 ROW_FORMAT=COMPACT COMMENT='角色权限定义表';

-- ----------------------------
-- Records of sys_role_menu
-- ----------------------------
INSERT INTO `sys_role_menu` VALUES ('1', '100');
INSERT INTO `sys_role_menu` VALUES ('1', '110');
INSERT INTO `sys_role_menu` VALUES ('1', '120');
INSERT INTO `sys_role_menu` VALUES ('1', '130');
INSERT INTO `sys_role_menu` VALUES ('1', '140');
INSERT INTO `sys_role_menu` VALUES ('1', '150');
INSERT INTO `sys_role_menu` VALUES ('1', '160');

-- ----------------------------
-- Table structure for sys_role_user
-- ----------------------------
DROP TABLE IF EXISTS `sys_role_user`;
CREATE TABLE `sys_role_user` (
  `user_id` int(11) NOT NULL COMMENT '用户ID',
  `role_id` int(11) NOT NULL COMMENT '角色ID',
  PRIMARY KEY (`user_id`,`role_id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 ROW_FORMAT=COMPACT COMMENT='用户角色表';

-- ----------------------------
-- Records of sys_role_user
-- ----------------------------
INSERT INTO `sys_role_user` VALUES ('3', '1');
INSERT INTO `sys_role_user` VALUES ('3', '2');

-- ----------------------------
-- Table structure for sys_user
-- ----------------------------
DROP TABLE IF EXISTS `sys_user`;
CREATE TABLE `sys_user` (
  `id` int(11) NOT NULL AUTO_INCREMENT COMMENT '主键',
  `user_name` varchar(20) DEFAULT NULL COMMENT '用户名',
  `account` varchar(20) DEFAULT NULL COMMENT '账号',
  `password` varchar(128) DEFAULT NULL COMMENT '密码',
  `phone` varchar(11) DEFAULT NULL COMMENT '手机',
  `email` varchar(50) DEFAULT NULL COMMENT '邮箱',
  `star_level` int(1) DEFAULT NULL COMMENT '星级',
  `status` tinyint(1) NOT NULL DEFAULT '1' COMMENT '状态(1:有效；0:无效)',
  `creator` varchar(20) DEFAULT NULL COMMENT '创建者',
  `creator_id` int(11) DEFAULT NULL COMMENT '创建者id',
  `create_time` timestamp NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  `modify_time` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '最后更新时间',
  PRIMARY KEY (`id`) USING BTREE,
  UNIQUE KEY `USERNAME` (`user_name`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC COMMENT='人员主数据';

-- ----------------------------
-- Records of sys_user
-- ----------------------------
INSERT INTO `sys_user` VALUES ('1', 'wang', 'wang', '123456', null, null, null, '1', null, null, '2020-08-21 16:59:10', '2020-08-21 16:59:10');
INSERT INTO `sys_user` VALUES ('2', '王志伟', 'wang-zw', 'e10adc3949ba59abbe56e057f20f883e', null, null, null, '1', null, null, '2020-10-28 17:09:22', '2020-10-28 17:09:22');
INSERT INTO `sys_user` VALUES ('3', null, 'admin', 'e10adc3949ba59abbe56e057f20f883e', null, null, null, '1', null, null, '2020-10-28 17:26:09', '2020-10-28 17:26:09');
