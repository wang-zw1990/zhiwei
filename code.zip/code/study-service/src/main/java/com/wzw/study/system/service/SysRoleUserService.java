package com.wzw.study.system.service;

import com.wzw.study.system.exception.ServiceException;
import com.wzw.study.system.model.Page;
import com.wzw.study.system.model.SysRoleMenu;
import com.wzw.study.system.model.SysRoleUser;
import com.wzw.study.system.query.SysRoleMenuQuery;
import com.wzw.study.system.query.SysRoleUserQuery;

import java.util.List;

/*
 * 版    权:  Copyright©2019 Beijing Eternal Research Co.,Ltd. All Right Reserved.
 * 描    述:
 * 修 改 人:  ETRES
 * 修改时间:
 * 修改内容:  新版作成
*/
public interface SysRoleUserService {

    /**
     * 查询
     * @param query
     * @return ServiceException
     */
    List<SysRoleUser> findList(SysRoleUserQuery query) throws ServiceException;

    /**
     * 删除
     * @param query
     * @throws ServiceException
     */
    Integer deleteByQuery(SysRoleUserQuery query) throws ServiceException;

    /**
     * 保存
     * @param entity
     * @throws ServiceException
     */
    public Integer saveOrUpdate(SysRoleUser entity) throws ServiceException;

}