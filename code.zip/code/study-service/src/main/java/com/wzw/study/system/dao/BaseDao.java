package com.wzw.study.system.dao;

import org.springframework.dao.DataAccessException;
import java.util.List;

/*
 * 版    权:  Copyright©2018  版权所有
 * 描    述:  数据访问共通接口
 * 修 改 人:  wang-zw
 * 修改时间:  2020-08-06
 * 修改内容:  新版作成
 */
public interface BaseDao<E, Q >{

	/** 获取分页列表 */
	List<E> findPage(Q query) throws DataAccessException;

	/** 获取分页总条数 */
	Long pageTotalCount(Q query) throws DataAccessException;

	/** 根据条件获取数据 */
	List<E> findList(Q query) throws DataAccessException;

	/** 通过ID获取单条数据 */
	E getById(Integer id) throws DataAccessException;

	/** 通过ID列表获取多条数据 */
	List<E> getByMultipleId(List<Integer> idList) throws DataAccessException;

	/** 通过ID删除单条数据 */
	Integer deleteById(Integer id) throws DataAccessException;

	/** 通过ID列表删除多条数据 */
	Integer deleteByMultipleId(List<Integer> idList) throws DataAccessException;

	/** 通过条件删除数据 */
	Integer deleteByQuery(Q query) throws DataAccessException;
	
	/** 插入数据 */
	Integer save(E entity) throws DataAccessException;
	
	/** 更新数据 */
	Integer update(E entity) throws DataAccessException;

}
