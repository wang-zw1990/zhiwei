package com.wzw.study.business.model;
import java.math.BigDecimal;
import java.util.Date;
import java.util.List;

import com.wzw.study.system.model.BaseEntity;
import com.fasterxml.jackson.annotation.JsonFormat;
import org.apache.commons.lang.builder.EqualsBuilder;
import org.apache.commons.lang.builder.HashCodeBuilder;
import org.apache.commons.lang.builder.ToStringBuilder;
import org.apache.commons.lang.builder.ToStringStyle;

import com.wzw.study.system.utils.DateConvertUtils;
import org.springframework.format.annotation.DateTimeFormat;

/*
 * 版    权:  Copyright©2019 Beijing Eternal Research Co.,Ltd. All Right Reserved.
 * 描    述:
 * 修 改 人:  ETRES
 * 修改时间:
 * 修改内容:  新版作成
*/
public class BusLeftNav extends BaseEntity<String> implements java.io.Serializable  {
    
	//alias
	public static final String TABLE_ALIAS = "左菜单";
	public static final String ALIAS_ID = "主键";
	public static final String ALIAS_PARENT_ID = "父ID";
	public static final String ALIAS_NAME = "功能名称";
	public static final String ALIAS_URL = "路由";
	public static final String ALIAS_IS_SHARE = "是否共享";
	public static final String ALIAS_SORT = "排序";
	public static final String ALIAS_IS_LOCAL = "是否本地";
	public static final String ALIAS_VIEW_TIMES = "浏览次数";
	public static final String ALIAS_PRAISE_TIMES = "praiseTimes";
	public static final String ALIAS_CREATOR = "创建者";
	public static final String ALIAS_CREATOR_ID = "创建者id";
	public static final String ALIAS_CREATE_TIME = "创建时间";
	public static final String ALIAS_MODIFY_TIME = "最后更新时间";
	
	//date formats
	public static final String FORMAT_PRAISE_TIMES = DATE_FORMAT;
	public static final String FORMAT_CREATE_TIME = DATE_FORMAT;
	public static final String FORMAT_MODIFY_TIME = DATE_FORMAT;
	
	
	//可以直接使用: @Length(max=50,message="用户名长度不能大于50")显示错误消息
	//columns START

    /**
     * 主键       db_column: id 
     */
	private java.lang.Integer id;

    /**
     * 父ID       db_column: parent_id 
     */
	private java.lang.Integer parentId;

    /**
     * 功能名称       db_column: name 
     */
	private java.lang.String name;

    /**
     * 路由       db_column: url 
     */
	private java.lang.String url;

    /**
     * 是否共享       db_column: is_share 
     */
	private java.lang.Boolean isShare;

    /**
     * 排序       db_column: sort 
     */
	private java.lang.Integer sort;

    /**
     * 是否本地       db_column: is_local 
     */
	private java.lang.Boolean isLocal;

    /**
     * 浏览次数       db_column: view_times 
     */
	private java.lang.Integer viewTimes;

    /**
     * praiseTimes       db_column: praise_times 
     */
	@DateTimeFormat(pattern="yyyy-MM-dd")
	@JsonFormat(pattern = "yyyy-MM-dd")
	private java.util.Date praiseTimes;

    /**
     * 创建者       db_column: creator 
     */
	private java.lang.String creator;

    /**
     * 创建者id       db_column: creator_id 
     */
	private java.lang.Integer creatorId;

    /**
     * 创建时间       db_column: create_time 
     */
	@DateTimeFormat(pattern="yyyy-MM-dd")
	@JsonFormat(pattern = "yyyy-MM-dd")
	private java.util.Date createTime;

    /**
     * 最后更新时间       db_column: modify_time 
     */
	@DateTimeFormat(pattern="yyyy-MM-dd")
	@JsonFormat(pattern = "yyyy-MM-dd")
	private java.util.Date modifyTime;
	//columns END

	public BusLeftNav(){
	}

	public BusLeftNav(
		java.lang.Integer id
	){
		this.id = id;
	}

	public void setId(java.lang.Integer value) {
		this.id = value;
	}
	public java.lang.Integer getId() {
		return this.id;
	}

	public void setParentId(java.lang.Integer value) {
		this.parentId = value;
	}
	public java.lang.Integer getParentId() {
		return this.parentId;
	}

	public void setName(java.lang.String value) {
		this.name = value;
	}
	public java.lang.String getName() {
		return this.name;
	}

	public void setUrl(java.lang.String value) {
		this.url = value;
	}
	public java.lang.String getUrl() {
		return this.url;
	}

	public void setIsShare(java.lang.Boolean value) {
		this.isShare = value;
	}
	public java.lang.Boolean getIsShare() {
		return this.isShare;
	}

	public void setSort(java.lang.Integer value) {
		this.sort = value;
	}
	public java.lang.Integer getSort() {
		return this.sort;
	}

	public void setIsLocal(java.lang.Boolean value) {
		this.isLocal = value;
	}
	public java.lang.Boolean getIsLocal() {
		return this.isLocal;
	}

	public void setViewTimes(java.lang.Integer value) {
		this.viewTimes = value;
	}
	public java.lang.Integer getViewTimes() {
		return this.viewTimes;
	}

	public String getPraiseTimesString() {
		return DateConvertUtils.format(getPraiseTimes(), FORMAT_PRAISE_TIMES);
	}
	public void setPraiseTimesString(String value) {
		setPraiseTimes(DateConvertUtils.parse(value, FORMAT_PRAISE_TIMES,java.util.Date.class));
	}
	
	public void setPraiseTimes(java.util.Date value) {
		this.praiseTimes = value;
	}
	public java.util.Date getPraiseTimes() {
		return this.praiseTimes;
	}

	public void setCreator(java.lang.String value) {
		this.creator = value;
	}
	public java.lang.String getCreator() {
		return this.creator;
	}

	public void setCreatorId(java.lang.Integer value) {
		this.creatorId = value;
	}
	public java.lang.Integer getCreatorId() {
		return this.creatorId;
	}

	public String getCreateTimeString() {
		return DateConvertUtils.format(getCreateTime(), FORMAT_CREATE_TIME);
	}
	public void setCreateTimeString(String value) {
		setCreateTime(DateConvertUtils.parse(value, FORMAT_CREATE_TIME,java.util.Date.class));
	}
	
	public void setCreateTime(java.util.Date value) {
		this.createTime = value;
	}
	public java.util.Date getCreateTime() {
		return this.createTime;
	}

	public String getModifyTimeString() {
		return DateConvertUtils.format(getModifyTime(), FORMAT_MODIFY_TIME);
	}
	public void setModifyTimeString(String value) {
		setModifyTime(DateConvertUtils.parse(value, FORMAT_MODIFY_TIME,java.util.Date.class));
	}
	
	public void setModifyTime(java.util.Date value) {
		this.modifyTime = value;
	}
	public java.util.Date getModifyTime() {
		return this.modifyTime;
	}


	public String toString() {
		return new ToStringBuilder(this,ToStringStyle.MULTI_LINE_STYLE)
			.append("Id",getId())
			.append("ParentId",getParentId())
			.append("Name",getName())
			.append("Url",getUrl())
			.append("IsShare",getIsShare())
			.append("Sort",getSort())
			.append("IsLocal",getIsLocal())
			.append("ViewTimes",getViewTimes())
			.append("PraiseTimes",getPraiseTimes())
			.append("Creator",getCreator())
			.append("CreatorId",getCreatorId())
			.append("CreateTime",getCreateTime())
			.append("ModifyTime",getModifyTime())
			.toString();
	}
	
	public int hashCode() {
		return new HashCodeBuilder()
			.append(getId())
			.toHashCode();
	}
	
	public boolean equals(Object obj) {
		if(obj instanceof BusLeftNav == false) return false;
		if(this == obj) return true;
		BusLeftNav other = (BusLeftNav)obj;
		return new EqualsBuilder()
			.append(getId(),other.getId())
			.isEquals();
	}
}

