package com.wzw.study.system.query;

import com.wzw.study.system.query.BaseQuery;
import org.apache.commons.lang.builder.ToStringBuilder;
import org.apache.commons.lang.builder.ToStringStyle;

import java.io.Serializable;
import java.math.BigDecimal;

import java.util.List;
import java.util.Date;

/*
 * 版    权:  Copyright©2019 Beijing Eternal Research Co.,Ltd. All Right Reserved.
 * 描    述:
 * 修 改 人:  ETRES
 * 修改时间:
 * 修改内容:  新版作成
*/
public class SysLogQuery extends BaseQuery implements Serializable {

	/** 主键 */
	private java.lang.Integer id;
	private java.lang.Integer idNotEq;
	private java.lang.Integer idGT;
	private java.lang.Integer idLT;
	
	private java.lang.Integer idGE;
	private java.lang.Integer idLE;
	
	private List<java.lang.Integer> idList;
	private List<java.lang.Integer> idNotEqList;
	/** 内容 */
	private java.lang.String content;
	private java.lang.String contentLike;
	private java.lang.String contentBeginLike;
	private java.lang.String contentEndLike;
	/** 创建者 */
	private java.lang.String creator;
	private java.lang.String creatorLike;
	private java.lang.String creatorBeginLike;
	private java.lang.String creatorEndLike;
	/** 创建者id */
	private java.lang.Integer creatorId;
	private java.lang.Integer creatorIdNotEq;
	private java.lang.Integer creatorIdGT;
	private java.lang.Integer creatorIdLT;
	
	private java.lang.Integer creatorIdGE;
	private java.lang.Integer creatorIdLE;
	
	private List<java.lang.Integer> creatorIdList;
	private List<java.lang.Integer> creatorIdNotEqList;
	/** 创建时间 */
	private java.util.Date createTimeBegin;
	private java.util.Date createTimeEnd;

	public java.lang.Integer getId() {
		return this.id;
	}
	public void setId(java.lang.Integer value) {
		this.id = value;
	}
	public java.lang.Integer getIdNotEq() {
		return idNotEq;
	}
	public void setIdNotEq(java.lang.Integer value) {
		this.idNotEq = value;
	}
	public java.lang.Integer getIdGT() {
		return idGT;
	}
	public void setIdGT(java.lang.Integer value) {
		this.idGT = value;
	}
	public java.lang.Integer getIdLT() {
		return idLT;
	}
	public void setIdLT(java.lang.Integer value) {
		this.idLT = value;
	}
	public java.lang.Integer getIdGE() {
		return idGE;
	}
	public void setIdGE(java.lang.Integer value) {
		this.idGE = value;
	}
	public java.lang.Integer getIdLE() {
		return idLE;
	}
	public void setIdLE(java.lang.Integer value) {
		this.idLE = value;
	}
	public List<java.lang.Integer> getIdList() {
		return this.idList;
	}
	public void setIdList(List<java.lang.Integer> value) {
		this.idList = value;
	}
	public List<java.lang.Integer> getIdNotEqList() {
		return idNotEqList;
	}
	public void setIdNotEqList(List<java.lang.Integer> value) {
		this.idNotEqList = value;
	}

	public java.lang.String getContent() {
		return this.content;
	}
	public void setContent(java.lang.String value) {
		this.content = value;
	}
	public java.lang.String getContentLike() {
		return this.contentLike;
	}
	public void setContentLike(java.lang.String value) {
		this.contentLike = value;
	}
	public java.lang.String getContentBeginLike() {
		return this.contentBeginLike;
	}
	public void setContentBeginLike(java.lang.String value) {
		this.contentBeginLike = value;
	}
	public java.lang.String getContentEndLike() {
		return this.contentEndLike;
	}
	public void setContentEndLike(java.lang.String value) {
		this.contentEndLike = value;
	}

	public java.lang.String getCreator() {
		return this.creator;
	}
	public void setCreator(java.lang.String value) {
		this.creator = value;
	}
	public java.lang.String getCreatorLike() {
		return this.creatorLike;
	}
	public void setCreatorLike(java.lang.String value) {
		this.creatorLike = value;
	}
	public java.lang.String getCreatorBeginLike() {
		return this.creatorBeginLike;
	}
	public void setCreatorBeginLike(java.lang.String value) {
		this.creatorBeginLike = value;
	}
	public java.lang.String getCreatorEndLike() {
		return this.creatorEndLike;
	}
	public void setCreatorEndLike(java.lang.String value) {
		this.creatorEndLike = value;
	}

	public java.lang.Integer getCreatorId() {
		return this.creatorId;
	}
	public void setCreatorId(java.lang.Integer value) {
		this.creatorId = value;
	}
	public java.lang.Integer getCreatorIdNotEq() {
		return creatorIdNotEq;
	}
	public void setCreatorIdNotEq(java.lang.Integer value) {
		this.creatorIdNotEq = value;
	}
	public java.lang.Integer getCreatorIdGT() {
		return creatorIdGT;
	}
	public void setCreatorIdGT(java.lang.Integer value) {
		this.creatorIdGT = value;
	}
	public java.lang.Integer getCreatorIdLT() {
		return creatorIdLT;
	}
	public void setCreatorIdLT(java.lang.Integer value) {
		this.creatorIdLT = value;
	}
	public java.lang.Integer getCreatorIdGE() {
		return creatorIdGE;
	}
	public void setCreatorIdGE(java.lang.Integer value) {
		this.creatorIdGE = value;
	}
	public java.lang.Integer getCreatorIdLE() {
		return creatorIdLE;
	}
	public void setCreatorIdLE(java.lang.Integer value) {
		this.creatorIdLE = value;
	}
	public List<java.lang.Integer> getCreatorIdList() {
		return this.creatorIdList;
	}
	public void setCreatorIdList(List<java.lang.Integer> value) {
		this.creatorIdList = value;
	}
	public List<java.lang.Integer> getCreatorIdNotEqList() {
		return creatorIdNotEqList;
	}
	public void setCreatorIdNotEqList(List<java.lang.Integer> value) {
		this.creatorIdNotEqList = value;
	}

	public java.util.Date getCreateTimeBegin() {
		return this.createTimeBegin;
	}
	public void setCreateTimeBegin(java.util.Date value) {
		this.createTimeBegin = value;
	}
	public java.util.Date getCreateTimeEnd() {
		return this.createTimeEnd;
	}
	public void setCreateTimeEnd(java.util.Date value) {
		this.createTimeEnd = value;
	}
	
	public String toString() {
		return ToStringBuilder.reflectionToString(this,ToStringStyle.MULTI_LINE_STYLE);
	}
	
}

