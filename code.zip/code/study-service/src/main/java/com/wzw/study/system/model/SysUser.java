package com.wzw.study.system.model;
import java.math.BigDecimal;
import java.util.Date;
import java.util.List;

import com.wzw.study.system.model.BaseEntity;
import com.fasterxml.jackson.annotation.JsonFormat;
import org.apache.commons.lang.builder.EqualsBuilder;
import org.apache.commons.lang.builder.HashCodeBuilder;
import org.apache.commons.lang.builder.ToStringBuilder;
import org.apache.commons.lang.builder.ToStringStyle;

import com.wzw.study.system.utils.DateConvertUtils;
import org.springframework.format.annotation.DateTimeFormat;

/*
 * 版    权:  Copyright©2019 Beijing Eternal Research Co.,Ltd. All Right Reserved.
 * 描    述:
 * 修 改 人:  ETRES
 * 修改时间:
 * 修改内容:  新版作成
*/
public class SysUser extends BaseEntity<String> implements java.io.Serializable  {
    
	//alias
	public static final String TABLE_ALIAS = "人员主数据";
	public static final String ALIAS_ID = "主键";
	public static final String ALIAS_USER_NAME = "用户名";
	public static final String ALIAS_ACCOUNT = "账号";
	public static final String ALIAS_PASSWORD = "密码";
	public static final String ALIAS_PHONE = "手机";
	public static final String ALIAS_EMAIL = "邮箱";
	public static final String ALIAS_STAR_LEVEL = "星级";
	public static final String ALIAS_STATUS = "状态(1:有效；0:无效)";
	public static final String ALIAS_CREATOR = "创建者";
	public static final String ALIAS_CREATOR_ID = "创建者id";
	public static final String ALIAS_CREATE_TIME = "创建时间";
	public static final String ALIAS_MODIFY_TIME = "最后更新时间";
	
	//date formats
	public static final String FORMAT_CREATE_TIME = DATE_FORMAT;
	public static final String FORMAT_MODIFY_TIME = DATE_FORMAT;
	
	
	//可以直接使用: @Length(max=50,message="用户名长度不能大于50")显示错误消息
	//columns START

    /**
     * 主键       db_column: id 
     */
	private java.lang.Integer id;

    /**
     * 用户名       db_column: user_name 
     */
	private java.lang.String userName;

    /**
     * 账号       db_column: account 
     */
	private java.lang.String account;

    /**
     * 密码       db_column: password 
     */
	private java.lang.String password;

    /**
     * 手机       db_column: phone 
     */
	private java.lang.String phone;

    /**
     * 邮箱       db_column: email 
     */
	private java.lang.String email;

    /**
     * 星级       db_column: star_level 
     */
	private java.lang.Integer starLevel;

    /**
     * 状态(1:有效；0:无效)       db_column: status 
     */
	private java.lang.Boolean status;

    /**
     * 创建者       db_column: creator 
     */
	private java.lang.String creator;

    /**
     * 创建者id       db_column: creator_id 
     */
	private java.lang.Integer creatorId;

    /**
     * 创建时间       db_column: create_time 
     */
	@DateTimeFormat(pattern="yyyy-MM-dd")
	@JsonFormat(pattern = "yyyy-MM-dd")
	private java.util.Date createTime;

    /**
     * 最后更新时间       db_column: modify_time 
     */
	@DateTimeFormat(pattern="yyyy-MM-dd")
	@JsonFormat(pattern = "yyyy-MM-dd")
	private java.util.Date modifyTime;
	//columns END

	public SysUser(){
	}

	public SysUser(
		java.lang.Integer id
	){
		this.id = id;
	}

	public void setId(java.lang.Integer value) {
		this.id = value;
	}
	public java.lang.Integer getId() {
		return this.id;
	}

	public void setUserName(java.lang.String value) {
		this.userName = value;
	}
	public java.lang.String getUserName() {
		return this.userName;
	}

	public void setAccount(java.lang.String value) {
		this.account = value;
	}
	public java.lang.String getAccount() {
		return this.account;
	}

	public void setPassword(java.lang.String value) {
		this.password = value;
	}
	public java.lang.String getPassword() {
		return this.password;
	}

	public void setPhone(java.lang.String value) {
		this.phone = value;
	}
	public java.lang.String getPhone() {
		return this.phone;
	}

	public void setEmail(java.lang.String value) {
		this.email = value;
	}
	public java.lang.String getEmail() {
		return this.email;
	}

	public void setStarLevel(java.lang.Integer value) {
		this.starLevel = value;
	}
	public java.lang.Integer getStarLevel() {
		return this.starLevel;
	}

	public void setStatus(java.lang.Boolean value) {
		this.status = value;
	}
	public java.lang.Boolean getStatus() {
		return this.status;
	}

	public void setCreator(java.lang.String value) {
		this.creator = value;
	}
	public java.lang.String getCreator() {
		return this.creator;
	}

	public void setCreatorId(java.lang.Integer value) {
		this.creatorId = value;
	}
	public java.lang.Integer getCreatorId() {
		return this.creatorId;
	}

	public String getCreateTimeString() {
		return DateConvertUtils.format(getCreateTime(), FORMAT_CREATE_TIME);
	}
	public void setCreateTimeString(String value) {
		setCreateTime(DateConvertUtils.parse(value, FORMAT_CREATE_TIME,java.util.Date.class));
	}
	
	public void setCreateTime(java.util.Date value) {
		this.createTime = value;
	}
	public java.util.Date getCreateTime() {
		return this.createTime;
	}

	public String getModifyTimeString() {
		return DateConvertUtils.format(getModifyTime(), FORMAT_MODIFY_TIME);
	}
	public void setModifyTimeString(String value) {
		setModifyTime(DateConvertUtils.parse(value, FORMAT_MODIFY_TIME,java.util.Date.class));
	}
	
	public void setModifyTime(java.util.Date value) {
		this.modifyTime = value;
	}
	public java.util.Date getModifyTime() {
		return this.modifyTime;
	}


	public String toString() {
		return new ToStringBuilder(this,ToStringStyle.MULTI_LINE_STYLE)
			.append("Id",getId())
			.append("UserName",getUserName())
			.append("Account",getAccount())
			.append("Password",getPassword())
			.append("Phone",getPhone())
			.append("Email",getEmail())
			.append("StarLevel",getStarLevel())
			.append("Status",getStatus())
			.append("Creator",getCreator())
			.append("CreatorId",getCreatorId())
			.append("CreateTime",getCreateTime())
			.append("ModifyTime",getModifyTime())
			.toString();
	}
	
	public int hashCode() {
		return new HashCodeBuilder()
			.append(getId())
			.toHashCode();
	}
	
	public boolean equals(Object obj) {
		if(obj instanceof SysUser == false) return false;
		if(this == obj) return true;
		SysUser other = (SysUser)obj;
		return new EqualsBuilder()
			.append(getId(),other.getId())
			.isEquals();
	}
}

