package com.wzw.study.system.req;

import java.util.List;


public class BaseReqParams<PK> implements java.io.Serializable {
    /**
     * serialVersionUID
     */
    private static final long serialVersionUID = 5427856441684932519L;

    List<PK> checkedIdList;
    
    public List<PK> getCheckedIdList()
    {
        return checkedIdList;
    }

    public void setCheckedIdList(List<PK> checkedIdList)
    {
        this.checkedIdList = checkedIdList;
    }
}
