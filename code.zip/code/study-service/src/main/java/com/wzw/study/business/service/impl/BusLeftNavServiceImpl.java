package com.wzw.study.business.service.impl;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.wzw.study.system.dao.BaseDao;
import org.apache.commons.lang.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.wzw.study.system.exception.ServiceException;
import com.wzw.study.system.service.impl.BaseServiceImpl;
import com.wzw.study.system.model.Page;

import com.wzw.study.business.dao.BusLeftNavDao;
import com.wzw.study.business.model.BusLeftNav;
import com.wzw.study.business.query.BusLeftNavQuery;
import com.wzw.study.business.service.BusLeftNavService;

import javax.annotation.Resource;

/*
 * 版    权:  Copyright©2019 Beijing Eternal Research Co.,Ltd. All Right Reserved.
 * 描    述:
 * 修 改 人:  ETRES
 * 修改时间:
 * 修改内容:  新版作成
*/
@Service
public class BusLeftNavServiceImpl extends BaseServiceImpl<BusLeftNav, BusLeftNavQuery> implements BusLeftNavService{

    @Autowired
    private BusLeftNavDao busLeftNavDao;

    @Override
    public BaseDao getBaseDao(){
        return busLeftNavDao;
    }

    @Override
    public Page<BusLeftNav> findPage(Page<BusLeftNav> page, BusLeftNavQuery query)
    {
        Long totalCount = busLeftNavDao.pageTotalCount(query);
        // 总件数
        page.setTotalCount(totalCount);
        
        if(totalCount == null || totalCount.longValue() <= 0) {
            page.setResult(new ArrayList<BusLeftNav>());
            return page;
        }
        
        Map<String, Object> otherFilters = new HashMap<String, Object>();
        otherFilters.put("offset", page.getCurrentFirst() - 1);
        otherFilters.put("pageSize", page.getPageSize());
        otherFilters.put("lastRows", page.getCurrentLast());
        
        StringBuffer  sortColumns = new StringBuffer();
        sortColumns.append(" ");
        if (page.isOrderBySetted()) {
            String[] orderByArray = StringUtils.split(page.getOrderBy(), ',');
            String[] orderArray = StringUtils.split(page.getOrder(), ',');
            
            for (int i = 0; i < orderByArray.length; i++) {
                if(i > 0) {
                    sortColumns.append(" , ");
                }
                String orderBy = orderByArray[i];
                if(orderByArray[i].endsWith("Name")) {
                    orderBy = " CONVERT( " + orderBy + " using gbk)";
                }
                sortColumns.append(orderBy);
                if (Page.ASC.equals(orderArray[i])) {
                    sortColumns.append(" ASC ");
                } else {
                    sortColumns.append(" DESC ");
                }
            }
        }
        if(!" ".equals(sortColumns.toString())) {
            query.setSortColumns(sortColumns.toString());
        }
        
        query.setOffset(page.getCurrentFirst()-1);
        query.setPageSize(page.getPageSize());
        query.setLastRows(page.getCurrentLast());
        
        List<BusLeftNav> result = busLeftNavDao.findPage(query);
        page.setResult(result);
                
        return page;
    }

    @Override
    public Integer saveOrUpdate(BusLeftNav entity) throws ServiceException {
        if(entity.getId() == null){
            return busLeftNavDao.save(entity);
        } else {
            return busLeftNavDao.update(entity);
        }
    }
}
