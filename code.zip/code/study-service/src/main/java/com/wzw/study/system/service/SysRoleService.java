package com.wzw.study.system.service;

import com.wzw.study.system.exception.ServiceException;
import com.wzw.study.system.model.Page;
import com.wzw.study.system.model.SysRole;
import com.wzw.study.system.query.SysRoleQuery;

/*
 * 版    权:  Copyright©2019 Beijing Eternal Research Co.,Ltd. All Right Reserved.
 * 描    述:
 * 修 改 人:  ETRES
 * 修改时间:
 * 修改内容:  新版作成
*/
public interface SysRoleService extends BaseService<SysRole, SysRoleQuery> {

    /**
     * 分页查询
     * @param page
     * @param query
     * @return
     */
    public Page<SysRole> findPage(Page<SysRole> page, SysRoleQuery query) throws ServiceException;

    /**
     * 保存
     * @param entity
     * @throws ServiceException
     */
    public Integer saveOrUpdate(SysRole entity) throws ServiceException;

}