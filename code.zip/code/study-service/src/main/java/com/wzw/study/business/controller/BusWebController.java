package com.wzw.study.business.controller;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.wzw.study.system.exception.ServiceException;
import com.wzw.study.system.controller.BaseController;
import com.wzw.study.system.model.Page;
import com.wzw.study.business.model.BusWeb;
import com.wzw.study.business.query.BusWebQuery;
import com.wzw.study.business.req.BusWebReqParams;
import com.wzw.study.business.service.BusWebService;
import java.util.List;

/*
 * 版    权:  Copyright©2019 Beijing Eternal Research Co.,Ltd. All Right Reserved.
 * 描    述:
 * 修 改 人:  ETRES
 * 修改时间:
 * 修改内容:  新版作成
*/
@Slf4j
@Api(tags = "角色定义表接口")
@RestController
@RequestMapping("/busweb")
public class BusWebController extends BaseController
{
    @Autowired
    private BusWebService busWebService;

    @ApiOperation(value = "获取分页列表")
    @RequestMapping(value = "/findPage", method = RequestMethod.POST)
    public Object findPage(BusWebReqParams params) throws Exception {
        try { 
            Page<BusWeb> page = null;
            if(params != null && params.getPage() != null) {
                page = params.getPage();
            }
            if(page == null){
                page = new Page<BusWeb>();
            }
            if (!page.isOrderBySetted()) {
                page.setOrderBy("id");
                page.setOrder(Page.DESC);               
            }
            
            BusWebQuery busWebQuery = null;
            if(params != null && params.getBusWebQuery() != null){
                busWebQuery = params.getBusWebQuery();
            }
            if(busWebQuery == null) {
                busWebQuery = new BusWebQuery();
            }
            
            page = busWebService.findPage(page, busWebQuery);
            return responseSuccessJson(page, "检索成功！");
            
        } catch(ServiceException ex) {
            return responseErrorJson(ex.getErrorInfo());
        } catch(Exception e) {
            return responseErrorJson(e.getMessage());
        }
    }

    @ApiOperation(value = "获取列表")
    @RequestMapping(value = "/findList", method = RequestMethod.POST)
    public Object findList(BusWebQuery query) throws Exception {
        try {
            if(query == null) {
                query = new BusWebQuery();
            }
            List<BusWeb> busWebList = busWebService.findList(query);
            return responseSuccessJson(busWebList, "获取成功！");
        } catch(ServiceException ex) {
            return responseErrorJson(ex.getErrorInfo());
        } catch(Exception e) {
            return responseErrorJson(e.getMessage());
        }
    }

    @ApiOperation(value = "获取单条数据")
    @RequestMapping(value = "/getById", method = RequestMethod.POST)
    public Object getById(java.lang.Integer id) throws Exception {
        try {   
            BusWeb busWeb = null;
            if(id != null){
                busWeb = busWebService.getById(id);
            }else{
                busWeb = new BusWeb();
            }
            
            return responseSuccessJson(busWeb, "检索成功！");
            
        } catch(ServiceException ex) {
            return responseErrorJson(ex.getErrorInfo());
        } catch(Exception e) {
            return responseErrorJson(e.getMessage());
        }
    }

    @ApiOperation(value = "保存数据")
    @RequestMapping(value = "/save", method = RequestMethod.POST)
    public Object save(BusWebReqParams params) throws Exception {
        try {   
            if(params != null && params.getBusWeb() != null){
                busWebService.saveOrUpdate(params.getBusWeb());
            }
            
            return responseSuccessJson(null, "保存成功！");
            
        } catch(ServiceException ex) {
            return responseErrorJson(ex.getErrorInfo());
        } catch(Exception e) {
            return responseErrorJson(e.getMessage());
        }
    }

    @ApiOperation(value = "删除数据")
    @RequestMapping(value = "/remove", method = RequestMethod.POST)
    public Object delete(BusWebReqParams params) throws Exception {
        try {   
            if(params != null && params.getCheckedIdList() != null && params.getCheckedIdList().size() > 0){
                busWebService.deleteByMultipleId(params.getCheckedIdList());
            }
            
            return responseSuccessJson(null, "删除成功！");
            
        } catch(ServiceException ex) {
            return responseErrorJson(ex.getErrorInfo());
        } catch(Exception e) {
            return responseErrorJson(e.getMessage());
        }
    }  
}
