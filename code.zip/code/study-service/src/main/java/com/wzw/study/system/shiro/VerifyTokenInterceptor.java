package com.wzw.study.system.shiro;

import com.wzw.study.system.utils.CookieUtil;
import com.wzw.study.system.utils.JWTUtil;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.web.servlet.HandlerInterceptor;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class VerifyTokenInterceptor implements HandlerInterceptor {

	private Logger logger = LoggerFactory.getLogger(VerifyTokenInterceptor.class);

	@Override
	public boolean preHandle(HttpServletRequest request, HttpServletResponse response, Object handler) throws Exception{
		try {
			Integer userId = JWTUtil.getUserId(request);
			logger.info("****userId = {}*****",userId);
			//todo 校验token是否合法，如果不合法拦截器做处理
		}catch (Exception e){
			e.printStackTrace();
		}
		return true;
	}
}
