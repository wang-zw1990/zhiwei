package com.wzw.study.system.controller;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.wzw.study.system.exception.ServiceException;
import com.wzw.study.system.model.Page;
import com.wzw.study.system.model.SysRoleMenu;
import com.wzw.study.system.query.SysRoleMenuQuery;
import com.wzw.study.system.req.SysRoleMenuReqParams;
import com.wzw.study.system.service.SysRoleMenuService;
import java.util.List;

/*
 * 版    权:  Copyright©2019 Beijing Eternal Research Co.,Ltd. All Right Reserved.
 * 描    述:
 * 修 改 人:  ETRES
 * 修改时间:
 * 修改内容:  新版作成
*/
@Slf4j
@Api(tags = "角色权限定义表接口")
@RestController
@RequestMapping("/sysrolemenu")
public class SysRoleMenuController extends BaseController
{
    @Autowired
    private SysRoleMenuService sysRoleMenuService;

    @ApiOperation(value = "获取列表")
    @RequestMapping(value = "/findList", method = RequestMethod.POST)
    public Object findList(SysRoleMenuQuery query) throws Exception {
        try {
            if(query == null) {
                query = new SysRoleMenuQuery();
            }
            List<SysRoleMenu> sysRoleMenuList = sysRoleMenuService.findList(query);
            return responseSuccessJson(sysRoleMenuList, "获取成功！");
        } catch(ServiceException ex) {
            return responseErrorJson(ex.getErrorInfo());
        } catch(Exception e) {
            return responseErrorJson(e.getMessage());
        }
    }

    @ApiOperation(value = "保存数据")
    @RequestMapping(value = "/save", method = RequestMethod.POST)
    public Object save(SysRoleMenuReqParams params) throws Exception {
        try {   
            if(params != null && params.getSysRoleMenu() != null){
                sysRoleMenuService.saveOrUpdate(params.getSysRoleMenu());
            }
            
            return responseSuccessJson(null, "保存成功！");
            
        } catch(ServiceException ex) {
            return responseErrorJson(ex.getErrorInfo());
        } catch(Exception e) {
            return responseErrorJson(e.getMessage());
        }
    }
}
