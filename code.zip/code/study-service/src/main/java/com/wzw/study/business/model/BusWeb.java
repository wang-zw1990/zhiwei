package com.wzw.study.business.model;
import java.math.BigDecimal;
import java.util.Date;
import java.util.List;

import com.wzw.study.system.model.BaseEntity;
import com.fasterxml.jackson.annotation.JsonFormat;
import org.apache.commons.lang.builder.EqualsBuilder;
import org.apache.commons.lang.builder.HashCodeBuilder;
import org.apache.commons.lang.builder.ToStringBuilder;
import org.apache.commons.lang.builder.ToStringStyle;

import com.wzw.study.system.utils.DateConvertUtils;
import org.springframework.format.annotation.DateTimeFormat;

/*
 * 版    权:  Copyright©2019 Beijing Eternal Research Co.,Ltd. All Right Reserved.
 * 描    述:
 * 修 改 人:  ETRES
 * 修改时间:
 * 修改内容:  新版作成
*/
public class BusWeb extends BaseEntity<String> implements java.io.Serializable  {
    
	//alias
	public static final String TABLE_ALIAS = "角色定义表";
	public static final String ALIAS_ID = "ID";
	public static final String ALIAS_LEFT_NAV_ID = "关联id";
	public static final String ALIAS_CONTENT = "内容";
	public static final String ALIAS_CREATOR = "创建者";
	public static final String ALIAS_CREATOR_ID = "创建者id";
	public static final String ALIAS_CREATE_TIME = "创建时间";
	public static final String ALIAS_MODIFY_TIME = "最后更新时间";
	
	//date formats
	public static final String FORMAT_CREATE_TIME = DATE_FORMAT;
	public static final String FORMAT_MODIFY_TIME = DATE_FORMAT;
	
	
	//可以直接使用: @Length(max=50,message="用户名长度不能大于50")显示错误消息
	//columns START

    /**
     * ID       db_column: id 
     */
	private java.lang.Integer id;

    /**
     * 关联id       db_column: left_nav_id 
     */
	private java.lang.Integer leftNavId;

    /**
     * 内容       db_column: content 
     */
	private java.lang.String content;

    /**
     * 创建者       db_column: creator 
     */
	private java.lang.String creator;

    /**
     * 创建者id       db_column: creator_id 
     */
	private java.lang.Integer creatorId;

    /**
     * 创建时间       db_column: create_time 
     */
	@DateTimeFormat(pattern="yyyy-MM-dd")
	@JsonFormat(pattern = "yyyy-MM-dd")
	private java.util.Date createTime;

    /**
     * 最后更新时间       db_column: modify_time 
     */
	@DateTimeFormat(pattern="yyyy-MM-dd")
	@JsonFormat(pattern = "yyyy-MM-dd")
	private java.util.Date modifyTime;
	//columns END

	public BusWeb(){
	}

	public BusWeb(
		java.lang.Integer id
	){
		this.id = id;
	}

	public void setId(java.lang.Integer value) {
		this.id = value;
	}
	public java.lang.Integer getId() {
		return this.id;
	}

	public void setLeftNavId(java.lang.Integer value) {
		this.leftNavId = value;
	}
	public java.lang.Integer getLeftNavId() {
		return this.leftNavId;
	}

	public void setContent(java.lang.String value) {
		this.content = value;
	}
	public java.lang.String getContent() {
		return this.content;
	}

	public void setCreator(java.lang.String value) {
		this.creator = value;
	}
	public java.lang.String getCreator() {
		return this.creator;
	}

	public void setCreatorId(java.lang.Integer value) {
		this.creatorId = value;
	}
	public java.lang.Integer getCreatorId() {
		return this.creatorId;
	}

	public String getCreateTimeString() {
		return DateConvertUtils.format(getCreateTime(), FORMAT_CREATE_TIME);
	}
	public void setCreateTimeString(String value) {
		setCreateTime(DateConvertUtils.parse(value, FORMAT_CREATE_TIME,java.util.Date.class));
	}
	
	public void setCreateTime(java.util.Date value) {
		this.createTime = value;
	}
	public java.util.Date getCreateTime() {
		return this.createTime;
	}

	public String getModifyTimeString() {
		return DateConvertUtils.format(getModifyTime(), FORMAT_MODIFY_TIME);
	}
	public void setModifyTimeString(String value) {
		setModifyTime(DateConvertUtils.parse(value, FORMAT_MODIFY_TIME,java.util.Date.class));
	}
	
	public void setModifyTime(java.util.Date value) {
		this.modifyTime = value;
	}
	public java.util.Date getModifyTime() {
		return this.modifyTime;
	}


	public String toString() {
		return new ToStringBuilder(this,ToStringStyle.MULTI_LINE_STYLE)
			.append("Id",getId())
			.append("LeftNavId",getLeftNavId())
			.append("Content",getContent())
			.append("Creator",getCreator())
			.append("CreatorId",getCreatorId())
			.append("CreateTime",getCreateTime())
			.append("ModifyTime",getModifyTime())
			.toString();
	}
	
	public int hashCode() {
		return new HashCodeBuilder()
			.append(getId())
			.toHashCode();
	}
	
	public boolean equals(Object obj) {
		if(obj instanceof BusWeb == false) return false;
		if(this == obj) return true;
		BusWeb other = (BusWeb)obj;
		return new EqualsBuilder()
			.append(getId(),other.getId())
			.isEquals();
	}
}

