package com.wzw.study.business.req;

import com.wzw.study.system.req.BaseReqParams;
import com.wzw.study.system.model.Page;
import com.wzw.study.business.model.BusLeftNav;
import com.wzw.study.business.query.BusLeftNavQuery;

public class BusLeftNavReqParams extends BaseReqParams
{

    /**
     * serialVersionUID
     */
    private static final long serialVersionUID = 4378148386606781306L;
    
    Page<BusLeftNav>  page;
    BusLeftNav        busLeftNav;
    BusLeftNavQuery   busLeftNavQuery;
    
    public Page<BusLeftNav> getPage()
    {
        return page;
    }
    public void setPage(Page<BusLeftNav> page)
    {
        this.page = page;
    }
    public BusLeftNav getBusLeftNav()
    {
        return busLeftNav;
    }
    public void setBusLeftNav(BusLeftNav busLeftNav)
    {
        this.busLeftNav = busLeftNav;
    }
    public BusLeftNavQuery getBusLeftNavQuery()
    {
        return busLeftNavQuery;
    }
    public void setBusLeftNavQuery(BusLeftNavQuery busLeftNavQuery)
    {
        this.busLeftNavQuery = busLeftNavQuery;
    }
}
