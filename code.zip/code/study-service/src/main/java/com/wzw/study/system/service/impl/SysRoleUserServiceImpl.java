package com.wzw.study.system.service.impl;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.wzw.study.system.dao.BaseDao;
import com.wzw.study.system.model.SysRoleMenu;
import com.wzw.study.system.query.SysRoleMenuQuery;
import org.apache.commons.lang.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.wzw.study.system.exception.ServiceException;
import com.wzw.study.system.model.Page;

import com.wzw.study.system.dao.SysRoleUserDao;
import com.wzw.study.system.model.SysRoleUser;
import com.wzw.study.system.query.SysRoleUserQuery;
import com.wzw.study.system.service.SysRoleUserService;
/*
 * 版    权:  Copyright©2019 Beijing Eternal Research Co.,Ltd. All Right Reserved.
 * 描    述:
 * 修 改 人:  ETRES
 * 修改时间:
 * 修改内容:  新版作成
*/
@Service
public class SysRoleUserServiceImpl implements SysRoleUserService{

    @Autowired
    private SysRoleUserDao sysRoleUserDao;

    @Override
    public List<SysRoleUser> findList(SysRoleUserQuery query) {
        return sysRoleUserDao.findList(query);
    }

    @Override
    public Integer deleteByQuery(SysRoleUserQuery query) throws ServiceException {
        return sysRoleUserDao.deleteByQuery(query);
    }

    @Override
    public Integer saveOrUpdate(SysRoleUser entity) throws ServiceException {
        return sysRoleUserDao.save(entity);
    }
}
