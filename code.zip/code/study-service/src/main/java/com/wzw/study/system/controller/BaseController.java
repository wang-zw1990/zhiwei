package com.wzw.study.system.controller;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.HashMap;
import java.util.Map;

public class BaseController {
	protected Logger log = LoggerFactory.getLogger(BaseController.class);
	
	protected final String SUCCESS = "success";
	protected final String FAILURE = "failure";
	
	public Map<String, Object> responseSuccessJson(Object returnObj, String info) {		
		Map<String, Object> returnMap = new HashMap<String, Object>();
		returnMap.put("r_code", 0);
		returnMap.put("r_info", info);
		returnMap.put("r_data", returnObj);
		
		return returnMap;
	}
	
	public Map<String, Object> responseErrorJson(String info) {
		Map<String, Object> returnMap = new HashMap<String, Object>();
		returnMap.put("r_code", -1);
		if(info == null) {
			returnMap.put("r_info", "登录状态异常，请重新登录！");
		}else {
			returnMap.put("r_info", info);
		}
		returnMap.put("r_data", null);
		
		return returnMap;
	}
	public Map<String, Object> responseSuccessJsonCon( String info) {		
		Map<String, Object> returnMap = new HashMap<String, Object>();
		returnMap.put("r_code", 0);
		returnMap.put("r_info", info);
		
		return returnMap;
	}
}
