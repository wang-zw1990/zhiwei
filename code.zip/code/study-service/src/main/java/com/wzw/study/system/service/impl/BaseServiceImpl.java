package com.wzw.study.system.service.impl;

import com.wzw.study.system.exception.ServiceException;
import com.wzw.study.system.dao.BaseDao;
import com.wzw.study.system.service.BaseService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import javax.transaction.Transactional;
import java.util.List;

/*
 * 版    权:  Copyright©2019 Beijing Eternal Research Co.,Ltd. All Right Reserved.
 * 描    述:
 * 修 改 人:  ETRES
 * 修改时间:
 * 修改内容:  新版作成
*/
public abstract class BaseServiceImpl<E, Q> implements BaseService<E, Q> {

    public abstract BaseDao<E, Q> getBaseDao() ;

    @Override
    public List<E> findList(Q query) {
        return getBaseDao().findList(query);
    }

    @Override
    public E getById(Integer id) {
        return getBaseDao().getById(id);
    }

    @Override
    public List<E> getByMultipleId(List<Integer> idList) {
        return getBaseDao().getByMultipleId(idList);
    }

    @Override
    public Integer deleteById(Integer id) throws ServiceException {
        return getBaseDao().deleteById(id);
    }

    @Override
    public Integer deleteByMultipleId(List<Integer> idList) throws ServiceException {
        return getBaseDao().deleteByMultipleId(idList);
    }

    @Override
    public Integer deleteByQuery(Q query) throws ServiceException {
        return getBaseDao().deleteByQuery(query);
    }
}
