package com.wzw.study.system.dao;
import com.wzw.study.system.model.SysRoleUser;
import com.wzw.study.system.query.SysRoleUserQuery;
import org.apache.ibatis.annotations.Mapper;
import com.wzw.study.system.dao.BaseDao;

import com.wzw.study.system.model.SysRoleMenu;
import com.wzw.study.system.query.SysRoleMenuQuery;
import org.springframework.dao.DataAccessException;
import org.springframework.stereotype.Repository;

import java.util.List;

/*
 * 版    权:  Copyright©2019 Beijing Eternal Research Co.,Ltd. All Right Reserved.
 * 描    述:
 * 修 改 人:  ETRES
 * 修改时间:
 * 修改内容:  新版作成
*/
@Mapper
@Repository
public interface SysRoleMenuDao {

    /** 根据条件获取数据 */
    List<SysRoleMenu> findList(SysRoleMenuQuery query) throws DataAccessException;

    /** 通过条件删除数据 */
    Integer deleteByQuery(SysRoleMenuQuery query) throws DataAccessException;

    /** 插入数据 */
    Integer save(SysRoleMenu entity) throws DataAccessException;

}