package com.wzw.study.system.req;

import com.wzw.study.system.req.BaseReqParams;
import com.wzw.study.system.model.Page;
import com.wzw.study.system.model.SysMenu;
import com.wzw.study.system.query.SysMenuQuery;

public class SysMenuReqParams extends BaseReqParams
{

    /**
     * serialVersionUID
     */
    private static final long serialVersionUID = 4378148386606781306L;
    
    Page<SysMenu>  page;
    SysMenu        sysMenu;
    SysMenuQuery   sysMenuQuery;
    
    public Page<SysMenu> getPage()
    {
        return page;
    }
    public void setPage(Page<SysMenu> page)
    {
        this.page = page;
    }
    public SysMenu getSysMenu()
    {
        return sysMenu;
    }
    public void setSysMenu(SysMenu sysMenu)
    {
        this.sysMenu = sysMenu;
    }
    public SysMenuQuery getSysMenuQuery()
    {
        return sysMenuQuery;
    }
    public void setSysMenuQuery(SysMenuQuery sysMenuQuery)
    {
        this.sysMenuQuery = sysMenuQuery;
    }
}
