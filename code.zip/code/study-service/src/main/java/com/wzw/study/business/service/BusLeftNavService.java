package com.wzw.study.business.service;

import com.wzw.study.system.exception.ServiceException;
import com.wzw.study.system.service.BaseService;
import com.wzw.study.system.model.Page;
import com.wzw.study.business.model.BusLeftNav;
import com.wzw.study.business.query.BusLeftNavQuery;

/*
 * 版    权:  Copyright©2019 Beijing Eternal Research Co.,Ltd. All Right Reserved.
 * 描    述:
 * 修 改 人:  ETRES
 * 修改时间:
 * 修改内容:  新版作成
*/
public interface BusLeftNavService extends BaseService<BusLeftNav, BusLeftNavQuery> {

    /**
     * 分页查询
     * @param page
     * @param query
     * @return
     */
    public Page<BusLeftNav> findPage(Page<BusLeftNav> page, BusLeftNavQuery query) throws ServiceException;

    /**
     * 保存
     * @param entity
     * @throws ServiceException
     */
    public Integer saveOrUpdate(BusLeftNav entity) throws ServiceException;

}