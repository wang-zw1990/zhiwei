package com.wzw.study.system.req;

import com.wzw.study.system.req.BaseReqParams;
import com.wzw.study.system.model.Page;
import com.wzw.study.system.model.SysRoleMenu;
import com.wzw.study.system.query.SysRoleMenuQuery;

public class SysRoleMenuReqParams extends BaseReqParams
{

    /**
     * serialVersionUID
     */
    private static final long serialVersionUID = 4378148386606781306L;
    
    Page<SysRoleMenu>  page;
    SysRoleMenu        sysRoleMenu;
    SysRoleMenuQuery   sysRoleMenuQuery;
    
    public Page<SysRoleMenu> getPage()
    {
        return page;
    }
    public void setPage(Page<SysRoleMenu> page)
    {
        this.page = page;
    }
    public SysRoleMenu getSysRoleMenu()
    {
        return sysRoleMenu;
    }
    public void setSysRoleMenu(SysRoleMenu sysRoleMenu)
    {
        this.sysRoleMenu = sysRoleMenu;
    }
    public SysRoleMenuQuery getSysRoleMenuQuery()
    {
        return sysRoleMenuQuery;
    }
    public void setSysRoleMenuQuery(SysRoleMenuQuery sysRoleMenuQuery)
    {
        this.sysRoleMenuQuery = sysRoleMenuQuery;
    }
}
