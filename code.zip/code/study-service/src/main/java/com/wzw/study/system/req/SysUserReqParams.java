package com.wzw.study.system.req;

import com.wzw.study.system.req.BaseReqParams;
import com.wzw.study.system.model.Page;
import com.wzw.study.system.model.SysUser;
import com.wzw.study.system.query.SysUserQuery;

public class SysUserReqParams extends BaseReqParams
{

    /**
     * serialVersionUID
     */
    private static final long serialVersionUID = 4378148386606781306L;
    
    Page<SysUser>  page;
    SysUser        sysUser;
    SysUserQuery   sysUserQuery;
    
    public Page<SysUser> getPage()
    {
        return page;
    }
    public void setPage(Page<SysUser> page)
    {
        this.page = page;
    }
    public SysUser getSysUser()
    {
        return sysUser;
    }
    public void setSysUser(SysUser sysUser)
    {
        this.sysUser = sysUser;
    }
    public SysUserQuery getSysUserQuery()
    {
        return sysUserQuery;
    }
    public void setSysUserQuery(SysUserQuery sysUserQuery)
    {
        this.sysUserQuery = sysUserQuery;
    }
}
