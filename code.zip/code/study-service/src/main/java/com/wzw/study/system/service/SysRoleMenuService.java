package com.wzw.study.system.service;

import com.wzw.study.system.exception.ServiceException;
import com.wzw.study.system.model.Page;
import com.wzw.study.system.model.SysRoleMenu;
import com.wzw.study.system.query.SysRoleMenuQuery;

import java.util.List;

/*
 * 版    权:  Copyright©2019 Beijing Eternal Research Co.,Ltd. All Right Reserved.
 * 描    述:
 * 修 改 人:  ETRES
 * 修改时间:
 * 修改内容:  新版作成
*/
public interface SysRoleMenuService {

    /**
     * 查询
     * @param query
     * @return ServiceException
     */
    List<SysRoleMenu> findList(SysRoleMenuQuery query) throws ServiceException;

    /**
     * 删除
     * @param query
     * @throws ServiceException
     */
    Integer deleteByQuery(SysRoleMenuQuery query) throws ServiceException;

    /**
     * 保存
     * @param entity
     * @throws ServiceException
     */
    public Integer saveOrUpdate(SysRoleMenu entity) throws ServiceException;

}