package com.wzw.study.business.controller;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.wzw.study.system.exception.ServiceException;
import com.wzw.study.system.controller.BaseController;
import com.wzw.study.system.model.Page;
import com.wzw.study.business.model.BusLeftNav;
import com.wzw.study.business.query.BusLeftNavQuery;
import com.wzw.study.business.req.BusLeftNavReqParams;
import com.wzw.study.business.service.BusLeftNavService;
import java.util.List;

/*
 * 版    权:  Copyright©2019 Beijing Eternal Research Co.,Ltd. All Right Reserved.
 * 描    述:
 * 修 改 人:  ETRES
 * 修改时间:
 * 修改内容:  新版作成
*/
@Slf4j
@Api(tags = "左菜单接口")
@RestController
@RequestMapping("/busleftnav")
public class BusLeftNavController extends BaseController
{
    @Autowired
    private BusLeftNavService busLeftNavService;

    @ApiOperation(value = "获取分页列表")
    @RequestMapping(value = "/findPage", method = RequestMethod.POST)
    public Object findPage(BusLeftNavReqParams params) throws Exception {
        try { 
            Page<BusLeftNav> page = null;
            if(params != null && params.getPage() != null) {
                page = params.getPage();
            }
            if(page == null){
                page = new Page<BusLeftNav>();
            }
            if (!page.isOrderBySetted()) {
                page.setOrderBy("id");
                page.setOrder(Page.DESC);               
            }
            
            BusLeftNavQuery busLeftNavQuery = null;
            if(params != null && params.getBusLeftNavQuery() != null){
                busLeftNavQuery = params.getBusLeftNavQuery();
            }
            if(busLeftNavQuery == null) {
                busLeftNavQuery = new BusLeftNavQuery();
            }
            
            page = busLeftNavService.findPage(page, busLeftNavQuery);
            return responseSuccessJson(page, "检索成功！");
            
        } catch(ServiceException ex) {
            return responseErrorJson(ex.getErrorInfo());
        } catch(Exception e) {
            return responseErrorJson(e.getMessage());
        }
    }

    @ApiOperation(value = "获取列表")
    @RequestMapping(value = "/findList", method = RequestMethod.POST)
    public Object findList(BusLeftNavQuery query) throws Exception {
        try {
            if(query == null) {
                query = new BusLeftNavQuery();
            }
            List<BusLeftNav> busLeftNavList = busLeftNavService.findList(query);
            return responseSuccessJson(busLeftNavList, "获取成功！");
        } catch(ServiceException ex) {
            return responseErrorJson(ex.getErrorInfo());
        } catch(Exception e) {
            return responseErrorJson(e.getMessage());
        }
    }

    @ApiOperation(value = "获取单条数据")
    @RequestMapping(value = "/getById", method = RequestMethod.POST)
    public Object getById(java.lang.Integer id) throws Exception {
        try {   
            BusLeftNav busLeftNav = null;
            if(id != null){
                busLeftNav = busLeftNavService.getById(id);
            }else{
                busLeftNav = new BusLeftNav();
            }
            
            return responseSuccessJson(busLeftNav, "检索成功！");
            
        } catch(ServiceException ex) {
            return responseErrorJson(ex.getErrorInfo());
        } catch(Exception e) {
            return responseErrorJson(e.getMessage());
        }
    }

    @ApiOperation(value = "保存数据")
    @RequestMapping(value = "/save", method = RequestMethod.POST)
    public Object save(BusLeftNavReqParams params) throws Exception {
        try {   
            if(params != null && params.getBusLeftNav() != null){
                busLeftNavService.saveOrUpdate(params.getBusLeftNav());
            }
            
            return responseSuccessJson(null, "保存成功！");
            
        } catch(ServiceException ex) {
            return responseErrorJson(ex.getErrorInfo());
        } catch(Exception e) {
            return responseErrorJson(e.getMessage());
        }
    }

    @ApiOperation(value = "删除数据")
    @RequestMapping(value = "/remove", method = RequestMethod.POST)
    public Object delete(BusLeftNavReqParams params) throws Exception {
        try {   
            if(params != null && params.getCheckedIdList() != null && params.getCheckedIdList().size() > 0){
                busLeftNavService.deleteByMultipleId(params.getCheckedIdList());
            }
            
            return responseSuccessJson(null, "删除成功！");
            
        } catch(ServiceException ex) {
            return responseErrorJson(ex.getErrorInfo());
        } catch(Exception e) {
            return responseErrorJson(e.getMessage());
        }
    }  
}
