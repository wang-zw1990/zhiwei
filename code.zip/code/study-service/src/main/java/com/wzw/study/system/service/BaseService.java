package com.wzw.study.system.service;

import com.wzw.study.system.exception.ServiceException;
import java.util.List;

/*
 * 版    权:  Copyright©2018  版权所有
 * 描    述:  
 * 修 改 人:  wang-zw
 * 修改时间:  2020-08-07
 * 修改内容:  新版作成
 */
public interface BaseService<E, Q> {

    /**
     * 查询
     * @param query
     * @return ServiceException
     */
    List<E> findList(Q query) throws ServiceException;

    /**
     * 查询单条记录
     * @param id
     * @throws ServiceException
     */
    E getById(Integer id) throws ServiceException;

    /**
     * 查询
     * @param idList
     * @return
     */
    List<E> getByMultipleId(List<Integer> idList) throws ServiceException;

    /**
     * 删除
     * @param id
     * @throws ServiceException
     */
    Integer deleteById(Integer id) throws ServiceException;

    /**
     * 删除
     * @param idList
     * @throws ServiceException
     */
    Integer deleteByMultipleId(List<Integer> idList) throws ServiceException;

    /**
     * 删除
     * @param query
     * @throws ServiceException
     */
    Integer deleteByQuery(Q query) throws ServiceException;

}