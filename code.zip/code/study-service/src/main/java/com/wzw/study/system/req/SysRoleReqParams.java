package com.wzw.study.system.req;

import com.wzw.study.system.req.BaseReqParams;
import com.wzw.study.system.model.Page;
import com.wzw.study.system.model.SysRole;
import com.wzw.study.system.query.SysRoleQuery;

public class SysRoleReqParams extends BaseReqParams
{

    /**
     * serialVersionUID
     */
    private static final long serialVersionUID = 4378148386606781306L;
    
    Page<SysRole>  page;
    SysRole        sysRole;
    SysRoleQuery   sysRoleQuery;
    
    public Page<SysRole> getPage()
    {
        return page;
    }
    public void setPage(Page<SysRole> page)
    {
        this.page = page;
    }
    public SysRole getSysRole()
    {
        return sysRole;
    }
    public void setSysRole(SysRole sysRole)
    {
        this.sysRole = sysRole;
    }
    public SysRoleQuery getSysRoleQuery()
    {
        return sysRoleQuery;
    }
    public void setSysRoleQuery(SysRoleQuery sysRoleQuery)
    {
        this.sysRoleQuery = sysRoleQuery;
    }
}
