package com.wzw.study.system.query;

import com.wzw.study.system.query.BaseQuery;
import org.apache.commons.lang.builder.ToStringBuilder;
import org.apache.commons.lang.builder.ToStringStyle;

import java.io.Serializable;
import java.math.BigDecimal;

import java.util.List;
import java.util.Date;

/*
 * 版    权:  Copyright©2019 Beijing Eternal Research Co.,Ltd. All Right Reserved.
 * 描    述:
 * 修 改 人:  ETRES
 * 修改时间:
 * 修改内容:  新版作成
*/
public class SysRoleQuery extends BaseQuery implements Serializable {

	/** ID */
	private java.lang.Integer id;
	private java.lang.Integer idNotEq;
	private java.lang.Integer idGT;
	private java.lang.Integer idLT;
	
	private java.lang.Integer idGE;
	private java.lang.Integer idLE;
	
	private List<java.lang.Integer> idList;
	private List<java.lang.Integer> idNotEqList;
	/** 角色名称 */
	private java.lang.String name;
	private java.lang.String nameLike;
	private java.lang.String nameBeginLike;
	private java.lang.String nameEndLike;
	/** 描述 */
	private java.lang.String description;
	private java.lang.String descriptionLike;
	private java.lang.String descriptionBeginLike;
	private java.lang.String descriptionEndLike;
	/** 创建者 */
	private java.lang.String creator;
	private java.lang.String creatorLike;
	private java.lang.String creatorBeginLike;
	private java.lang.String creatorEndLike;
	/** 创建者id */
	private java.lang.Integer creatorId;
	private java.lang.Integer creatorIdNotEq;
	private java.lang.Integer creatorIdGT;
	private java.lang.Integer creatorIdLT;
	
	private java.lang.Integer creatorIdGE;
	private java.lang.Integer creatorIdLE;
	
	private List<java.lang.Integer> creatorIdList;
	private List<java.lang.Integer> creatorIdNotEqList;
	/** 创建时间 */
	private java.util.Date createTimeBegin;
	private java.util.Date createTimeEnd;
	/** 最后更新时间 */
	private java.util.Date modifyTimeBegin;
	private java.util.Date modifyTimeEnd;

	public java.lang.Integer getId() {
		return this.id;
	}
	public void setId(java.lang.Integer value) {
		this.id = value;
	}
	public java.lang.Integer getIdNotEq() {
		return idNotEq;
	}
	public void setIdNotEq(java.lang.Integer value) {
		this.idNotEq = value;
	}
	public java.lang.Integer getIdGT() {
		return idGT;
	}
	public void setIdGT(java.lang.Integer value) {
		this.idGT = value;
	}
	public java.lang.Integer getIdLT() {
		return idLT;
	}
	public void setIdLT(java.lang.Integer value) {
		this.idLT = value;
	}
	public java.lang.Integer getIdGE() {
		return idGE;
	}
	public void setIdGE(java.lang.Integer value) {
		this.idGE = value;
	}
	public java.lang.Integer getIdLE() {
		return idLE;
	}
	public void setIdLE(java.lang.Integer value) {
		this.idLE = value;
	}
	public List<java.lang.Integer> getIdList() {
		return this.idList;
	}
	public void setIdList(List<java.lang.Integer> value) {
		this.idList = value;
	}
	public List<java.lang.Integer> getIdNotEqList() {
		return idNotEqList;
	}
	public void setIdNotEqList(List<java.lang.Integer> value) {
		this.idNotEqList = value;
	}

	public java.lang.String getName() {
		return this.name;
	}
	public void setName(java.lang.String value) {
		this.name = value;
	}
	public java.lang.String getNameLike() {
		return this.nameLike;
	}
	public void setNameLike(java.lang.String value) {
		this.nameLike = value;
	}
	public java.lang.String getNameBeginLike() {
		return this.nameBeginLike;
	}
	public void setNameBeginLike(java.lang.String value) {
		this.nameBeginLike = value;
	}
	public java.lang.String getNameEndLike() {
		return this.nameEndLike;
	}
	public void setNameEndLike(java.lang.String value) {
		this.nameEndLike = value;
	}

	public java.lang.String getDescription() {
		return this.description;
	}
	public void setDescription(java.lang.String value) {
		this.description = value;
	}
	public java.lang.String getDescriptionLike() {
		return this.descriptionLike;
	}
	public void setDescriptionLike(java.lang.String value) {
		this.descriptionLike = value;
	}
	public java.lang.String getDescriptionBeginLike() {
		return this.descriptionBeginLike;
	}
	public void setDescriptionBeginLike(java.lang.String value) {
		this.descriptionBeginLike = value;
	}
	public java.lang.String getDescriptionEndLike() {
		return this.descriptionEndLike;
	}
	public void setDescriptionEndLike(java.lang.String value) {
		this.descriptionEndLike = value;
	}

	public java.lang.String getCreator() {
		return this.creator;
	}
	public void setCreator(java.lang.String value) {
		this.creator = value;
	}
	public java.lang.String getCreatorLike() {
		return this.creatorLike;
	}
	public void setCreatorLike(java.lang.String value) {
		this.creatorLike = value;
	}
	public java.lang.String getCreatorBeginLike() {
		return this.creatorBeginLike;
	}
	public void setCreatorBeginLike(java.lang.String value) {
		this.creatorBeginLike = value;
	}
	public java.lang.String getCreatorEndLike() {
		return this.creatorEndLike;
	}
	public void setCreatorEndLike(java.lang.String value) {
		this.creatorEndLike = value;
	}

	public java.lang.Integer getCreatorId() {
		return this.creatorId;
	}
	public void setCreatorId(java.lang.Integer value) {
		this.creatorId = value;
	}
	public java.lang.Integer getCreatorIdNotEq() {
		return creatorIdNotEq;
	}
	public void setCreatorIdNotEq(java.lang.Integer value) {
		this.creatorIdNotEq = value;
	}
	public java.lang.Integer getCreatorIdGT() {
		return creatorIdGT;
	}
	public void setCreatorIdGT(java.lang.Integer value) {
		this.creatorIdGT = value;
	}
	public java.lang.Integer getCreatorIdLT() {
		return creatorIdLT;
	}
	public void setCreatorIdLT(java.lang.Integer value) {
		this.creatorIdLT = value;
	}
	public java.lang.Integer getCreatorIdGE() {
		return creatorIdGE;
	}
	public void setCreatorIdGE(java.lang.Integer value) {
		this.creatorIdGE = value;
	}
	public java.lang.Integer getCreatorIdLE() {
		return creatorIdLE;
	}
	public void setCreatorIdLE(java.lang.Integer value) {
		this.creatorIdLE = value;
	}
	public List<java.lang.Integer> getCreatorIdList() {
		return this.creatorIdList;
	}
	public void setCreatorIdList(List<java.lang.Integer> value) {
		this.creatorIdList = value;
	}
	public List<java.lang.Integer> getCreatorIdNotEqList() {
		return creatorIdNotEqList;
	}
	public void setCreatorIdNotEqList(List<java.lang.Integer> value) {
		this.creatorIdNotEqList = value;
	}

	public java.util.Date getCreateTimeBegin() {
		return this.createTimeBegin;
	}
	public void setCreateTimeBegin(java.util.Date value) {
		this.createTimeBegin = value;
	}
	public java.util.Date getCreateTimeEnd() {
		return this.createTimeEnd;
	}
	public void setCreateTimeEnd(java.util.Date value) {
		this.createTimeEnd = value;
	}
	
	public java.util.Date getModifyTimeBegin() {
		return this.modifyTimeBegin;
	}
	public void setModifyTimeBegin(java.util.Date value) {
		this.modifyTimeBegin = value;
	}
	public java.util.Date getModifyTimeEnd() {
		return this.modifyTimeEnd;
	}
	public void setModifyTimeEnd(java.util.Date value) {
		this.modifyTimeEnd = value;
	}
	
	public String toString() {
		return ToStringBuilder.reflectionToString(this,ToStringStyle.MULTI_LINE_STYLE);
	}
	
}

