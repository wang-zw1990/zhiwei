package com.wzw.study.system.controller;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.wzw.study.system.exception.ServiceException;
import com.wzw.study.system.model.Page;
import com.wzw.study.system.model.SysRole;
import com.wzw.study.system.query.SysRoleQuery;
import com.wzw.study.system.req.SysRoleReqParams;
import com.wzw.study.system.service.SysRoleService;
import java.util.List;

/*
 * 版    权:  Copyright©2019 Beijing Eternal Research Co.,Ltd. All Right Reserved.
 * 描    述:
 * 修 改 人:  ETRES
 * 修改时间:
 * 修改内容:  新版作成
*/
@Slf4j
@Api(tags = "角色定义表接口")
@RestController
@RequestMapping("/sysrole")
public class SysRoleController extends BaseController
{
    @Autowired
    private SysRoleService sysRoleService;

    @ApiOperation(value = "获取分页列表")
    @RequestMapping(value = "/findPage", method = RequestMethod.POST)
    public Object findPage(SysRoleReqParams params) throws Exception {
        try { 
            Page<SysRole> page = null;
            if(params != null && params.getPage() != null) {
                page = params.getPage();
            }
            if(page == null){
                page = new Page<SysRole>();
            }
            if (!page.isOrderBySetted()) {
                page.setOrderBy("id");
                page.setOrder(Page.DESC);               
            }
            
            SysRoleQuery sysRoleQuery = null;
            if(params != null && params.getSysRoleQuery() != null){
                sysRoleQuery = params.getSysRoleQuery();
            }
            if(sysRoleQuery == null) {
                sysRoleQuery = new SysRoleQuery();
            }
            
            page = sysRoleService.findPage(page, sysRoleQuery);
            return responseSuccessJson(page, "检索成功！");
            
        } catch(ServiceException ex) {
            return responseErrorJson(ex.getErrorInfo());
        } catch(Exception e) {
            return responseErrorJson(e.getMessage());
        }
    }

    @ApiOperation(value = "获取列表")
    @RequestMapping(value = "/findList", method = RequestMethod.POST)
    public Object findList(SysRoleQuery query) throws Exception {
        try {
            if(query == null) {
                query = new SysRoleQuery();
            }
            List<SysRole> sysRoleList = sysRoleService.findList(query);
            return responseSuccessJson(sysRoleList, "获取成功！");
        } catch(ServiceException ex) {
            return responseErrorJson(ex.getErrorInfo());
        } catch(Exception e) {
            return responseErrorJson(e.getMessage());
        }
    }

    @ApiOperation(value = "获取单条数据")
    @RequestMapping(value = "/getById", method = RequestMethod.POST)
    public Object getById(java.lang.Integer id) throws Exception {
        try {   
            SysRole sysRole = null;
            if(id != null){
                sysRole = sysRoleService.getById(id);
            }else{
                sysRole = new SysRole();
            }
            
            return responseSuccessJson(sysRole, "检索成功！");
            
        } catch(ServiceException ex) {
            return responseErrorJson(ex.getErrorInfo());
        } catch(Exception e) {
            return responseErrorJson(e.getMessage());
        }
    }

    @ApiOperation(value = "保存数据")
    @RequestMapping(value = "/save", method = RequestMethod.POST)
    public Object save(SysRoleReqParams params) throws Exception {
        try {   
            if(params != null && params.getSysRole() != null){
                sysRoleService.saveOrUpdate(params.getSysRole());
            }
            
            return responseSuccessJson(null, "保存成功！");
            
        } catch(ServiceException ex) {
            return responseErrorJson(ex.getErrorInfo());
        } catch(Exception e) {
            return responseErrorJson(e.getMessage());
        }
    }

    @ApiOperation(value = "删除数据")
    @RequestMapping(value = "/remove", method = RequestMethod.POST)
    public Object delete(SysRoleReqParams params) throws Exception {
        try {   
            if(params != null && params.getCheckedIdList() != null && params.getCheckedIdList().size() > 0){
                sysRoleService.deleteByMultipleId(params.getCheckedIdList());
            }
            
            return responseSuccessJson(null, "删除成功！");
            
        } catch(ServiceException ex) {
            return responseErrorJson(ex.getErrorInfo());
        } catch(Exception e) {
            return responseErrorJson(e.getMessage());
        }
    }  
}
