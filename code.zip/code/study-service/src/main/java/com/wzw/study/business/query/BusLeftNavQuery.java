package com.wzw.study.business.query;

import com.wzw.study.system.query.BaseQuery;
import org.apache.commons.lang.builder.ToStringBuilder;
import org.apache.commons.lang.builder.ToStringStyle;

import java.io.Serializable;
import java.math.BigDecimal;

import java.util.List;
import java.util.Date;

/*
 * 版    权:  Copyright©2019 Beijing Eternal Research Co.,Ltd. All Right Reserved.
 * 描    述:
 * 修 改 人:  ETRES
 * 修改时间:
 * 修改内容:  新版作成
*/
public class BusLeftNavQuery extends BaseQuery implements Serializable {

	/** 主键 */
	private java.lang.Integer id;
	private java.lang.Integer idNotEq;
	private java.lang.Integer idGT;
	private java.lang.Integer idLT;
	
	private java.lang.Integer idGE;
	private java.lang.Integer idLE;
	
	private List<java.lang.Integer> idList;
	private List<java.lang.Integer> idNotEqList;
	/** 父ID */
	private java.lang.Integer parentId;
	private java.lang.Integer parentIdNotEq;
	private java.lang.Integer parentIdGT;
	private java.lang.Integer parentIdLT;
	
	private java.lang.Integer parentIdGE;
	private java.lang.Integer parentIdLE;
	
	private List<java.lang.Integer> parentIdList;
	private List<java.lang.Integer> parentIdNotEqList;
	/** 功能名称 */
	private java.lang.String name;
	private java.lang.String nameLike;
	private java.lang.String nameBeginLike;
	private java.lang.String nameEndLike;
	/** 路由 */
	private java.lang.String url;
	private java.lang.String urlLike;
	private java.lang.String urlBeginLike;
	private java.lang.String urlEndLike;
	/** 是否共享 */
	private java.lang.Boolean isShare;
	/** 排序 */
	private java.lang.Integer sort;
	private java.lang.Integer sortNotEq;
	private java.lang.Integer sortGT;
	private java.lang.Integer sortLT;
	
	private java.lang.Integer sortGE;
	private java.lang.Integer sortLE;
	
	private List<java.lang.Integer> sortList;
	private List<java.lang.Integer> sortNotEqList;
	/** 是否本地 */
	private java.lang.Boolean isLocal;
	/** 浏览次数 */
	private java.lang.Integer viewTimes;
	private java.lang.Integer viewTimesNotEq;
	private java.lang.Integer viewTimesGT;
	private java.lang.Integer viewTimesLT;
	
	private java.lang.Integer viewTimesGE;
	private java.lang.Integer viewTimesLE;
	
	private List<java.lang.Integer> viewTimesList;
	private List<java.lang.Integer> viewTimesNotEqList;
	/** praiseTimes */
	private java.util.Date praiseTimesBegin;
	private java.util.Date praiseTimesEnd;
	/** 创建者 */
	private java.lang.String creator;
	private java.lang.String creatorLike;
	private java.lang.String creatorBeginLike;
	private java.lang.String creatorEndLike;
	/** 创建者id */
	private java.lang.Integer creatorId;
	private java.lang.Integer creatorIdNotEq;
	private java.lang.Integer creatorIdGT;
	private java.lang.Integer creatorIdLT;
	
	private java.lang.Integer creatorIdGE;
	private java.lang.Integer creatorIdLE;
	
	private List<java.lang.Integer> creatorIdList;
	private List<java.lang.Integer> creatorIdNotEqList;
	/** 创建时间 */
	private java.util.Date createTimeBegin;
	private java.util.Date createTimeEnd;
	/** 最后更新时间 */
	private java.util.Date modifyTimeBegin;
	private java.util.Date modifyTimeEnd;

	public java.lang.Integer getId() {
		return this.id;
	}
	public void setId(java.lang.Integer value) {
		this.id = value;
	}
	public java.lang.Integer getIdNotEq() {
		return idNotEq;
	}
	public void setIdNotEq(java.lang.Integer value) {
		this.idNotEq = value;
	}
	public java.lang.Integer getIdGT() {
		return idGT;
	}
	public void setIdGT(java.lang.Integer value) {
		this.idGT = value;
	}
	public java.lang.Integer getIdLT() {
		return idLT;
	}
	public void setIdLT(java.lang.Integer value) {
		this.idLT = value;
	}
	public java.lang.Integer getIdGE() {
		return idGE;
	}
	public void setIdGE(java.lang.Integer value) {
		this.idGE = value;
	}
	public java.lang.Integer getIdLE() {
		return idLE;
	}
	public void setIdLE(java.lang.Integer value) {
		this.idLE = value;
	}
	public List<java.lang.Integer> getIdList() {
		return this.idList;
	}
	public void setIdList(List<java.lang.Integer> value) {
		this.idList = value;
	}
	public List<java.lang.Integer> getIdNotEqList() {
		return idNotEqList;
	}
	public void setIdNotEqList(List<java.lang.Integer> value) {
		this.idNotEqList = value;
	}

	public java.lang.Integer getParentId() {
		return this.parentId;
	}
	public void setParentId(java.lang.Integer value) {
		this.parentId = value;
	}
	public java.lang.Integer getParentIdNotEq() {
		return parentIdNotEq;
	}
	public void setParentIdNotEq(java.lang.Integer value) {
		this.parentIdNotEq = value;
	}
	public java.lang.Integer getParentIdGT() {
		return parentIdGT;
	}
	public void setParentIdGT(java.lang.Integer value) {
		this.parentIdGT = value;
	}
	public java.lang.Integer getParentIdLT() {
		return parentIdLT;
	}
	public void setParentIdLT(java.lang.Integer value) {
		this.parentIdLT = value;
	}
	public java.lang.Integer getParentIdGE() {
		return parentIdGE;
	}
	public void setParentIdGE(java.lang.Integer value) {
		this.parentIdGE = value;
	}
	public java.lang.Integer getParentIdLE() {
		return parentIdLE;
	}
	public void setParentIdLE(java.lang.Integer value) {
		this.parentIdLE = value;
	}
	public List<java.lang.Integer> getParentIdList() {
		return this.parentIdList;
	}
	public void setParentIdList(List<java.lang.Integer> value) {
		this.parentIdList = value;
	}
	public List<java.lang.Integer> getParentIdNotEqList() {
		return parentIdNotEqList;
	}
	public void setParentIdNotEqList(List<java.lang.Integer> value) {
		this.parentIdNotEqList = value;
	}

	public java.lang.String getName() {
		return this.name;
	}
	public void setName(java.lang.String value) {
		this.name = value;
	}
	public java.lang.String getNameLike() {
		return this.nameLike;
	}
	public void setNameLike(java.lang.String value) {
		this.nameLike = value;
	}
	public java.lang.String getNameBeginLike() {
		return this.nameBeginLike;
	}
	public void setNameBeginLike(java.lang.String value) {
		this.nameBeginLike = value;
	}
	public java.lang.String getNameEndLike() {
		return this.nameEndLike;
	}
	public void setNameEndLike(java.lang.String value) {
		this.nameEndLike = value;
	}

	public java.lang.String getUrl() {
		return this.url;
	}
	public void setUrl(java.lang.String value) {
		this.url = value;
	}
	public java.lang.String getUrlLike() {
		return this.urlLike;
	}
	public void setUrlLike(java.lang.String value) {
		this.urlLike = value;
	}
	public java.lang.String getUrlBeginLike() {
		return this.urlBeginLike;
	}
	public void setUrlBeginLike(java.lang.String value) {
		this.urlBeginLike = value;
	}
	public java.lang.String getUrlEndLike() {
		return this.urlEndLike;
	}
	public void setUrlEndLike(java.lang.String value) {
		this.urlEndLike = value;
	}

	public java.lang.Boolean getIsShare() {
		return this.isShare;
	}
	public void setIsShare(java.lang.Boolean value) {
		this.isShare = value;
	}
	
	public java.lang.Integer getSort() {
		return this.sort;
	}
	public void setSort(java.lang.Integer value) {
		this.sort = value;
	}
	public java.lang.Integer getSortNotEq() {
		return sortNotEq;
	}
	public void setSortNotEq(java.lang.Integer value) {
		this.sortNotEq = value;
	}
	public java.lang.Integer getSortGT() {
		return sortGT;
	}
	public void setSortGT(java.lang.Integer value) {
		this.sortGT = value;
	}
	public java.lang.Integer getSortLT() {
		return sortLT;
	}
	public void setSortLT(java.lang.Integer value) {
		this.sortLT = value;
	}
	public java.lang.Integer getSortGE() {
		return sortGE;
	}
	public void setSortGE(java.lang.Integer value) {
		this.sortGE = value;
	}
	public java.lang.Integer getSortLE() {
		return sortLE;
	}
	public void setSortLE(java.lang.Integer value) {
		this.sortLE = value;
	}
	public List<java.lang.Integer> getSortList() {
		return this.sortList;
	}
	public void setSortList(List<java.lang.Integer> value) {
		this.sortList = value;
	}
	public List<java.lang.Integer> getSortNotEqList() {
		return sortNotEqList;
	}
	public void setSortNotEqList(List<java.lang.Integer> value) {
		this.sortNotEqList = value;
	}

	public java.lang.Boolean getIsLocal() {
		return this.isLocal;
	}
	public void setIsLocal(java.lang.Boolean value) {
		this.isLocal = value;
	}
	
	public java.lang.Integer getViewTimes() {
		return this.viewTimes;
	}
	public void setViewTimes(java.lang.Integer value) {
		this.viewTimes = value;
	}
	public java.lang.Integer getViewTimesNotEq() {
		return viewTimesNotEq;
	}
	public void setViewTimesNotEq(java.lang.Integer value) {
		this.viewTimesNotEq = value;
	}
	public java.lang.Integer getViewTimesGT() {
		return viewTimesGT;
	}
	public void setViewTimesGT(java.lang.Integer value) {
		this.viewTimesGT = value;
	}
	public java.lang.Integer getViewTimesLT() {
		return viewTimesLT;
	}
	public void setViewTimesLT(java.lang.Integer value) {
		this.viewTimesLT = value;
	}
	public java.lang.Integer getViewTimesGE() {
		return viewTimesGE;
	}
	public void setViewTimesGE(java.lang.Integer value) {
		this.viewTimesGE = value;
	}
	public java.lang.Integer getViewTimesLE() {
		return viewTimesLE;
	}
	public void setViewTimesLE(java.lang.Integer value) {
		this.viewTimesLE = value;
	}
	public List<java.lang.Integer> getViewTimesList() {
		return this.viewTimesList;
	}
	public void setViewTimesList(List<java.lang.Integer> value) {
		this.viewTimesList = value;
	}
	public List<java.lang.Integer> getViewTimesNotEqList() {
		return viewTimesNotEqList;
	}
	public void setViewTimesNotEqList(List<java.lang.Integer> value) {
		this.viewTimesNotEqList = value;
	}

	public java.util.Date getPraiseTimesBegin() {
		return this.praiseTimesBegin;
	}
	public void setPraiseTimesBegin(java.util.Date value) {
		this.praiseTimesBegin = value;
	}
	public java.util.Date getPraiseTimesEnd() {
		return this.praiseTimesEnd;
	}
	public void setPraiseTimesEnd(java.util.Date value) {
		this.praiseTimesEnd = value;
	}
	
	public java.lang.String getCreator() {
		return this.creator;
	}
	public void setCreator(java.lang.String value) {
		this.creator = value;
	}
	public java.lang.String getCreatorLike() {
		return this.creatorLike;
	}
	public void setCreatorLike(java.lang.String value) {
		this.creatorLike = value;
	}
	public java.lang.String getCreatorBeginLike() {
		return this.creatorBeginLike;
	}
	public void setCreatorBeginLike(java.lang.String value) {
		this.creatorBeginLike = value;
	}
	public java.lang.String getCreatorEndLike() {
		return this.creatorEndLike;
	}
	public void setCreatorEndLike(java.lang.String value) {
		this.creatorEndLike = value;
	}

	public java.lang.Integer getCreatorId() {
		return this.creatorId;
	}
	public void setCreatorId(java.lang.Integer value) {
		this.creatorId = value;
	}
	public java.lang.Integer getCreatorIdNotEq() {
		return creatorIdNotEq;
	}
	public void setCreatorIdNotEq(java.lang.Integer value) {
		this.creatorIdNotEq = value;
	}
	public java.lang.Integer getCreatorIdGT() {
		return creatorIdGT;
	}
	public void setCreatorIdGT(java.lang.Integer value) {
		this.creatorIdGT = value;
	}
	public java.lang.Integer getCreatorIdLT() {
		return creatorIdLT;
	}
	public void setCreatorIdLT(java.lang.Integer value) {
		this.creatorIdLT = value;
	}
	public java.lang.Integer getCreatorIdGE() {
		return creatorIdGE;
	}
	public void setCreatorIdGE(java.lang.Integer value) {
		this.creatorIdGE = value;
	}
	public java.lang.Integer getCreatorIdLE() {
		return creatorIdLE;
	}
	public void setCreatorIdLE(java.lang.Integer value) {
		this.creatorIdLE = value;
	}
	public List<java.lang.Integer> getCreatorIdList() {
		return this.creatorIdList;
	}
	public void setCreatorIdList(List<java.lang.Integer> value) {
		this.creatorIdList = value;
	}
	public List<java.lang.Integer> getCreatorIdNotEqList() {
		return creatorIdNotEqList;
	}
	public void setCreatorIdNotEqList(List<java.lang.Integer> value) {
		this.creatorIdNotEqList = value;
	}

	public java.util.Date getCreateTimeBegin() {
		return this.createTimeBegin;
	}
	public void setCreateTimeBegin(java.util.Date value) {
		this.createTimeBegin = value;
	}
	public java.util.Date getCreateTimeEnd() {
		return this.createTimeEnd;
	}
	public void setCreateTimeEnd(java.util.Date value) {
		this.createTimeEnd = value;
	}
	
	public java.util.Date getModifyTimeBegin() {
		return this.modifyTimeBegin;
	}
	public void setModifyTimeBegin(java.util.Date value) {
		this.modifyTimeBegin = value;
	}
	public java.util.Date getModifyTimeEnd() {
		return this.modifyTimeEnd;
	}
	public void setModifyTimeEnd(java.util.Date value) {
		this.modifyTimeEnd = value;
	}
	
	public String toString() {
		return ToStringBuilder.reflectionToString(this,ToStringStyle.MULTI_LINE_STYLE);
	}
	
}

