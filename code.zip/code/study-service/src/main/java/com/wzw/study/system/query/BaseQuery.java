package com.wzw.study.system.query;

/*
 * 版    权:  Copyright©2018  版权所有
 * 描    述:  分页查询基础类
 * 修 改 人:
 * 修改时间:  2018-06-06
 * 修改内容:  新版作成
 */
public class BaseQuery implements java.io.Serializable {

    private static final long serialVersionUID = -610954131828728454L;

	/** 排序字段 */
	private String sortColumns;

	/** 分页处理用 */
	private long offset;

	/** 每页数据条目数  */
	private long pageSize;

	/** 总条目数  */
	private long lastRows;

	private Boolean queryShowAll = false;

	public String getSortColumns() {
		return sortColumns;
	}

	public void setSortColumns(String sortColumns) {
		this.sortColumns = sortColumns;
	}

	public long getOffset() {
		return offset;
	}

	public void setOffset(long offset) {
		this.offset = offset;
	}

	public long getPageSize() {
		return pageSize;
	}

	public void setPageSize(long pageSize) {
		this.pageSize = pageSize;
	}

	public long getLastRows() {
		return lastRows;
	}

	public void setLastRows(long lastRows) {
		this.lastRows = lastRows;
	}

	public Boolean getQueryShowAll() {
		return queryShowAll;
	}

	public void setQueryShowAll(Boolean queryShowAll) {
		this.queryShowAll = queryShowAll;
	}
}
