package com.wzw.study.system.dao;
import org.apache.ibatis.annotations.Mapper;
import com.wzw.study.system.dao.BaseDao;

import com.wzw.study.system.model.SysRole;
import com.wzw.study.system.query.SysRoleQuery;
import org.springframework.stereotype.Repository;

/*
 * 版    权:  Copyright©2019 Beijing Eternal Research Co.,Ltd. All Right Reserved.
 * 描    述:
 * 修 改 人:  ETRES
 * 修改时间:
 * 修改内容:  新版作成
*/
@Mapper
@Repository
public interface SysRoleDao extends BaseDao<SysRole, SysRoleQuery>{
  //
}