package com.wzw.study.system.model;
import java.math.BigDecimal;
import java.util.Date;
import java.util.List;

import com.wzw.study.system.model.BaseEntity;
import com.fasterxml.jackson.annotation.JsonFormat;
import org.apache.commons.lang.builder.EqualsBuilder;
import org.apache.commons.lang.builder.HashCodeBuilder;
import org.apache.commons.lang.builder.ToStringBuilder;
import org.apache.commons.lang.builder.ToStringStyle;

import com.wzw.study.system.utils.DateConvertUtils;
import org.springframework.format.annotation.DateTimeFormat;

/*
 * 版    权:  Copyright©2019 Beijing Eternal Research Co.,Ltd. All Right Reserved.
 * 描    述:
 * 修 改 人:  ETRES
 * 修改时间:
 * 修改内容:  新版作成
*/
public class SysRoleUser extends BaseEntity<String> implements java.io.Serializable  {
    
	//alias
	public static final String TABLE_ALIAS = "用户角色表";
	public static final String ALIAS_USER_ID = "用户ID";
	public static final String ALIAS_ROLE_ID = "角色ID";
	
	//date formats
	
	
	//可以直接使用: @Length(max=50,message="用户名长度不能大于50")显示错误消息
	//columns START

    /**
     * 用户ID       db_column: user_id 
     */
	private java.lang.String userId;

    /**
     * 角色ID       db_column: role_id 
     */
	private java.lang.Integer roleId;
	//columns END

	public SysRoleUser(){
	}

	public SysRoleUser(
		java.lang.String userId,
		java.lang.Integer roleId
	){
		this.userId = userId;
		this.roleId = roleId;
	}

	public void setUserId(java.lang.String value) {
		this.userId = value;
	}
	public java.lang.String getUserId() {
		return this.userId;
	}

	public void setRoleId(java.lang.Integer value) {
		this.roleId = value;
	}
	public java.lang.Integer getRoleId() {
		return this.roleId;
	}


	public String toString() {
		return new ToStringBuilder(this,ToStringStyle.MULTI_LINE_STYLE)
			.append("UserId",getUserId())
			.append("RoleId",getRoleId())
			.toString();
	}
	
	public int hashCode() {
		return new HashCodeBuilder()
			.append(getUserId())
			.append(getRoleId())
			.toHashCode();
	}
	
	public boolean equals(Object obj) {
		if(obj instanceof SysRoleUser == false) return false;
		if(this == obj) return true;
		SysRoleUser other = (SysRoleUser)obj;
		return new EqualsBuilder()
			.append(getUserId(),other.getUserId())
			.append(getRoleId(),other.getRoleId())
			.isEquals();
	}
}

