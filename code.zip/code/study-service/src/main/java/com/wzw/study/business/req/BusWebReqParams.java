package com.wzw.study.business.req;

import com.wzw.study.system.req.BaseReqParams;
import com.wzw.study.system.model.Page;
import com.wzw.study.business.model.BusWeb;
import com.wzw.study.business.query.BusWebQuery;

public class BusWebReqParams extends BaseReqParams
{

    /**
     * serialVersionUID
     */
    private static final long serialVersionUID = 4378148386606781306L;
    
    Page<BusWeb>  page;
    BusWeb        busWeb;
    BusWebQuery   busWebQuery;
    
    public Page<BusWeb> getPage()
    {
        return page;
    }
    public void setPage(Page<BusWeb> page)
    {
        this.page = page;
    }
    public BusWeb getBusWeb()
    {
        return busWeb;
    }
    public void setBusWeb(BusWeb busWeb)
    {
        this.busWeb = busWeb;
    }
    public BusWebQuery getBusWebQuery()
    {
        return busWebQuery;
    }
    public void setBusWebQuery(BusWebQuery busWebQuery)
    {
        this.busWebQuery = busWebQuery;
    }
}
