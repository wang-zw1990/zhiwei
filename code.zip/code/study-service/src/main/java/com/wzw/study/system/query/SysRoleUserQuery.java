package com.wzw.study.system.query;

import com.wzw.study.system.query.BaseQuery;
import org.apache.commons.lang.builder.ToStringBuilder;
import org.apache.commons.lang.builder.ToStringStyle;

import java.io.Serializable;
import java.math.BigDecimal;

import java.util.List;
import java.util.Date;

/*
 * 版    权:  Copyright©2019 Beijing Eternal Research Co.,Ltd. All Right Reserved.
 * 描    述:
 * 修 改 人:  ETRES
 * 修改时间:
 * 修改内容:  新版作成
*/
public class SysRoleUserQuery extends BaseQuery implements Serializable {

	/** 用户ID */
	private java.lang.String userId;
	private java.lang.String userIdLike;
	private java.lang.String userIdBeginLike;
	private java.lang.String userIdEndLike;
	/** 角色ID */
	private java.lang.Integer roleId;
	private java.lang.Integer roleIdNotEq;
	private java.lang.Integer roleIdGT;
	private java.lang.Integer roleIdLT;
	
	private java.lang.Integer roleIdGE;
	private java.lang.Integer roleIdLE;
	
	private List<java.lang.Integer> roleIdList;
	private List<java.lang.Integer> roleIdNotEqList;

	public java.lang.String getUserId() {
		return this.userId;
	}
	public void setUserId(java.lang.String value) {
		this.userId = value;
	}
	public java.lang.String getUserIdLike() {
		return this.userIdLike;
	}
	public void setUserIdLike(java.lang.String value) {
		this.userIdLike = value;
	}
	public java.lang.String getUserIdBeginLike() {
		return this.userIdBeginLike;
	}
	public void setUserIdBeginLike(java.lang.String value) {
		this.userIdBeginLike = value;
	}
	public java.lang.String getUserIdEndLike() {
		return this.userIdEndLike;
	}
	public void setUserIdEndLike(java.lang.String value) {
		this.userIdEndLike = value;
	}

	public java.lang.Integer getRoleId() {
		return this.roleId;
	}
	public void setRoleId(java.lang.Integer value) {
		this.roleId = value;
	}
	public java.lang.Integer getRoleIdNotEq() {
		return roleIdNotEq;
	}
	public void setRoleIdNotEq(java.lang.Integer value) {
		this.roleIdNotEq = value;
	}
	public java.lang.Integer getRoleIdGT() {
		return roleIdGT;
	}
	public void setRoleIdGT(java.lang.Integer value) {
		this.roleIdGT = value;
	}
	public java.lang.Integer getRoleIdLT() {
		return roleIdLT;
	}
	public void setRoleIdLT(java.lang.Integer value) {
		this.roleIdLT = value;
	}
	public java.lang.Integer getRoleIdGE() {
		return roleIdGE;
	}
	public void setRoleIdGE(java.lang.Integer value) {
		this.roleIdGE = value;
	}
	public java.lang.Integer getRoleIdLE() {
		return roleIdLE;
	}
	public void setRoleIdLE(java.lang.Integer value) {
		this.roleIdLE = value;
	}
	public List<java.lang.Integer> getRoleIdList() {
		return this.roleIdList;
	}
	public void setRoleIdList(List<java.lang.Integer> value) {
		this.roleIdList = value;
	}
	public List<java.lang.Integer> getRoleIdNotEqList() {
		return roleIdNotEqList;
	}
	public void setRoleIdNotEqList(List<java.lang.Integer> value) {
		this.roleIdNotEqList = value;
	}

	public String toString() {
		return ToStringBuilder.reflectionToString(this,ToStringStyle.MULTI_LINE_STYLE);
	}
	
}

