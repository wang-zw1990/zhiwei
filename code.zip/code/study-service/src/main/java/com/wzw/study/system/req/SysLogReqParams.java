package com.wzw.study.system.req;

import com.wzw.study.system.req.BaseReqParams;
import com.wzw.study.system.model.Page;
import com.wzw.study.system.model.SysLog;
import com.wzw.study.system.query.SysLogQuery;

public class SysLogReqParams extends BaseReqParams
{

    /**
     * serialVersionUID
     */
    private static final long serialVersionUID = 4378148386606781306L;
    
    Page<SysLog>  page;
    SysLog        sysLog;
    SysLogQuery   sysLogQuery;
    
    public Page<SysLog> getPage()
    {
        return page;
    }
    public void setPage(Page<SysLog> page)
    {
        this.page = page;
    }
    public SysLog getSysLog()
    {
        return sysLog;
    }
    public void setSysLog(SysLog sysLog)
    {
        this.sysLog = sysLog;
    }
    public SysLogQuery getSysLogQuery()
    {
        return sysLogQuery;
    }
    public void setSysLogQuery(SysLogQuery sysLogQuery)
    {
        this.sysLogQuery = sysLogQuery;
    }
}
