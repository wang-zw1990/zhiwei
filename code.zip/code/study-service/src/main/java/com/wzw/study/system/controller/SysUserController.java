package com.wzw.study.system.controller;

import com.wzw.study.system.redis.RedisService;
import com.wzw.study.system.utils.AESUtil;
import com.wzw.study.system.utils.CookieUtil;
import com.wzw.study.system.utils.JWTUtil;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.wzw.study.system.exception.ServiceException;
import com.wzw.study.system.model.Page;
import com.wzw.study.system.model.SysUser;
import com.wzw.study.system.query.SysUserQuery;
import com.wzw.study.system.req.SysUserReqParams;
import com.wzw.study.system.service.SysUserService;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.util.List;

/*
 * 版    权:  Copyright©2019 Beijing Eternal Research Co.,Ltd. All Right Reserved.
 * 描    述:
 * 修 改 人:  ETRES
 * 修改时间:
 * 修改内容:  新版作成
*/
@Slf4j
@Api(tags = "用户接口")
@RestController
@RequestMapping("/sysuser")
public class SysUserController extends BaseController
{
    @Autowired
    private SysUserService sysUserService;

    @Autowired
    private RedisService redisService;

    @ApiOperation(value = "获取分页列表")
    @RequestMapping(value = "/findPage", method = RequestMethod.POST)
    public Object findPage(SysUserReqParams params) throws Exception {
        try { 
            Page<SysUser> page = null;
            if(params != null && params.getPage() != null) {
                page = params.getPage();
            }
            if(page == null){
                page = new Page<SysUser>();
            }
            if (!page.isOrderBySetted()) {
                page.setOrderBy("id");
                page.setOrder(Page.DESC);               
            }
            
            SysUserQuery sysUserQuery = null;
            if(params != null && params.getSysUserQuery() != null){
                sysUserQuery = params.getSysUserQuery();
            }
            if(sysUserQuery == null) {
                sysUserQuery = new SysUserQuery();
            }
            
            page = sysUserService.findPage(page, sysUserQuery);
            return responseSuccessJson(page, "检索成功！");
            
        } catch(ServiceException ex) {
            return responseErrorJson(ex.getErrorInfo());
        } catch(Exception e) {
            return responseErrorJson(e.getMessage());
        }
    }

    @ApiOperation(value = "获取列表")
    @RequestMapping(value = "/findList", method = RequestMethod.POST)
    public Object findList(SysUserQuery query) throws Exception {
        try {
            if(query == null) {
                query = new SysUserQuery();
            }
            List<SysUser> sysUserList = sysUserService.findList(query);
            return responseSuccessJson(sysUserList, "获取成功！");
        } catch(ServiceException ex) {
            return responseErrorJson(ex.getErrorInfo());
        } catch(Exception e) {
            return responseErrorJson(e.getMessage());
        }
    }

    @ApiOperation(value = "获取单条数据")
    @RequestMapping(value = "/getById", method = RequestMethod.POST)
    public Object getById(java.lang.Integer id, HttpServletRequest request) throws Exception {
        try {   
            SysUser sysUser = null;
            if(id != null){
                sysUser = sysUserService.getById(id);
            }else{
                sysUser = new SysUser();
            }
            return responseSuccessJson(sysUser, "检索成功！");
            
        } catch(ServiceException ex) {
            return responseErrorJson(ex.getErrorInfo());
        } catch(Exception e) {
            return responseErrorJson(e.getMessage());
        }
    }

    @ApiOperation(value = "保存数据")
    @RequestMapping(value = "/save", method = RequestMethod.POST)
    public Object save(SysUserReqParams params) throws Exception {
        try {   
            if(params != null && params.getSysUser() != null){
                sysUserService.saveOrUpdate(params.getSysUser());
            }
            
            return responseSuccessJson(null, "保存成功！");
            
        } catch(ServiceException ex) {
            return responseErrorJson(ex.getErrorInfo());
        } catch(Exception e) {
            return responseErrorJson(e.getMessage());
        }
    }

    @ApiOperation(value = "删除数据")
    @RequestMapping(value = "/remove", method = RequestMethod.POST)
    public Object delete(SysUserReqParams params) throws Exception {
        try {   
            if(params != null && params.getCheckedIdList() != null && params.getCheckedIdList().size() > 0){
                sysUserService.deleteByMultipleId(params.getCheckedIdList());
            }
            
            return responseSuccessJson(null, "删除成功！");
            
        } catch(ServiceException ex) {
            return responseErrorJson(ex.getErrorInfo());
        } catch(Exception e) {
            return responseErrorJson(e.getMessage());
        }
    }

    @ApiOperation(value = "用户登录")
    @RequestMapping(value = "/login", method = RequestMethod.POST)
    public Object login(String account,String password, HttpServletResponse response) throws Exception {
        try {
            //password = AESUtil.desEncrypt(password);
            //redisService.set("keyword","23423423");
            //System.out.println(redisService.get("keyword"));


            SysUserQuery query = new SysUserQuery();
            query.setAccount(account);
            query.setPassword(password);
            List<SysUser> list = sysUserService.findList(query);
            if (list!=null && list.size() > 0 ) {
                String token = JWTUtil.createToken(list.get(0).getId());
                CookieUtil.set(response,"token",token,5 * 60 * 1000);
                return responseSuccessJson(null, "登录成功！");
            } else {
                return responseErrorJson("用户名或密码错误");
            }

        } catch(ServiceException ex) {
            return responseErrorJson(ex.getErrorInfo());
        } catch(Exception e) {
            return responseErrorJson(e.getMessage());
        }
    }
}
