package com.wzw.study.system.model;
import java.math.BigDecimal;
import java.util.Date;
import java.util.List;

import com.wzw.study.system.model.BaseEntity;
import com.fasterxml.jackson.annotation.JsonFormat;
import org.apache.commons.lang.builder.EqualsBuilder;
import org.apache.commons.lang.builder.HashCodeBuilder;
import org.apache.commons.lang.builder.ToStringBuilder;
import org.apache.commons.lang.builder.ToStringStyle;

import com.wzw.study.system.utils.DateConvertUtils;
import org.springframework.format.annotation.DateTimeFormat;

/*
 * 版    权:  Copyright©2019 Beijing Eternal Research Co.,Ltd. All Right Reserved.
 * 描    述:
 * 修 改 人:  ETRES
 * 修改时间:
 * 修改内容:  新版作成
*/
public class SysRoleMenu extends BaseEntity<String> implements java.io.Serializable  {
    
	//alias
	public static final String TABLE_ALIAS = "角色权限定义表";
	public static final String ALIAS_ROLE_ID = "角色ID";
	public static final String ALIAS_MENU_ID = "权限ID";
	
	//date formats
	
	
	//可以直接使用: @Length(max=50,message="用户名长度不能大于50")显示错误消息
	//columns START

    /**
     * 角色ID       db_column: role_id 
     */
	private java.lang.Integer roleId;

    /**
     * 权限ID       db_column: menu_id 
     */
	private java.lang.Integer menuId;
	//columns END

	public SysRoleMenu(){
	}

	public SysRoleMenu(
		java.lang.Integer roleId,
		java.lang.Integer menuId
	){
		this.roleId = roleId;
		this.menuId = menuId;
	}

	public void setRoleId(java.lang.Integer value) {
		this.roleId = value;
	}
	public java.lang.Integer getRoleId() {
		return this.roleId;
	}

	public void setMenuId(java.lang.Integer value) {
		this.menuId = value;
	}
	public java.lang.Integer getMenuId() {
		return this.menuId;
	}


	public String toString() {
		return new ToStringBuilder(this,ToStringStyle.MULTI_LINE_STYLE)
			.append("RoleId",getRoleId())
			.append("MenuId",getMenuId())
			.toString();
	}
	
	public int hashCode() {
		return new HashCodeBuilder()
			.append(getRoleId())
			.append(getMenuId())
			.toHashCode();
	}
	
	public boolean equals(Object obj) {
		if(obj instanceof SysRoleMenu == false) return false;
		if(this == obj) return true;
		SysRoleMenu other = (SysRoleMenu)obj;
		return new EqualsBuilder()
			.append(getRoleId(),other.getRoleId())
			.append(getMenuId(),other.getMenuId())
			.isEquals();
	}
}

