package com.wzw.study.system.req;

import com.wzw.study.system.req.BaseReqParams;
import com.wzw.study.system.model.Page;
import com.wzw.study.system.model.SysRoleUser;
import com.wzw.study.system.query.SysRoleUserQuery;

public class SysRoleUserReqParams extends BaseReqParams
{

    /**
     * serialVersionUID
     */
    private static final long serialVersionUID = 4378148386606781306L;
    
    Page<SysRoleUser>  page;
    SysRoleUser        sysRoleUser;
    SysRoleUserQuery   sysRoleUserQuery;
    
    public Page<SysRoleUser> getPage()
    {
        return page;
    }
    public void setPage(Page<SysRoleUser> page)
    {
        this.page = page;
    }
    public SysRoleUser getSysRoleUser()
    {
        return sysRoleUser;
    }
    public void setSysRoleUser(SysRoleUser sysRoleUser)
    {
        this.sysRoleUser = sysRoleUser;
    }
    public SysRoleUserQuery getSysRoleUserQuery()
    {
        return sysRoleUserQuery;
    }
    public void setSysRoleUserQuery(SysRoleUserQuery sysRoleUserQuery)
    {
        this.sysRoleUserQuery = sysRoleUserQuery;
    }
}
