package com.wzw.study.system.service.impl;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.wzw.study.system.dao.BaseDao;
import org.apache.commons.lang.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.wzw.study.system.exception.ServiceException;
import com.wzw.study.system.model.Page;

import com.wzw.study.system.dao.SysLogDao;
import com.wzw.study.system.model.SysLog;
import com.wzw.study.system.query.SysLogQuery;
import com.wzw.study.system.service.SysLogService;
/*
 * 版    权:  Copyright©2019 Beijing Eternal Research Co.,Ltd. All Right Reserved.
 * 描    述:
 * 修 改 人:  ETRES
 * 修改时间:
 * 修改内容:  新版作成
*/
@Service
public class SysLogServiceImpl extends BaseServiceImpl<SysLog, SysLogQuery> implements SysLogService{
    @Autowired
    private SysLogDao sysLogDao;

    @Override
    public BaseDao getBaseDao(){
        return sysLogDao;
    }

    @Override
    public Page<SysLog> findPage(Page<SysLog> page, SysLogQuery query)
    {
        Long totalCount = sysLogDao.pageTotalCount(query);
        // 总件数
        page.setTotalCount(totalCount);
        
        if(totalCount == null || totalCount.longValue() <= 0) {
            page.setResult(new ArrayList<SysLog>());
            return page;
        }
        
        Map<String, Object> otherFilters = new HashMap<String, Object>();
        otherFilters.put("offset", page.getCurrentFirst() - 1);
        otherFilters.put("pageSize", page.getPageSize());
        otherFilters.put("lastRows", page.getCurrentLast());
        
        StringBuffer  sortColumns = new StringBuffer();
        sortColumns.append(" ");
        if (page.isOrderBySetted()) {
            String[] orderByArray = StringUtils.split(page.getOrderBy(), ',');
            String[] orderArray = StringUtils.split(page.getOrder(), ',');
            
            for (int i = 0; i < orderByArray.length; i++) {
                if(i > 0) {
                    sortColumns.append(" , ");
                }
                String orderBy = orderByArray[i];
                if(orderByArray[i].endsWith("Name")) {
                    orderBy = " CONVERT( " + orderBy + " using gbk)";
                }
                sortColumns.append(orderBy);
                if (Page.ASC.equals(orderArray[i])) {
                    sortColumns.append(" ASC ");
                } else {
                    sortColumns.append(" DESC ");
                }
            }
        }
        if(!" ".equals(sortColumns.toString())) {
            query.setSortColumns(sortColumns.toString());
        }
        
        query.setOffset(page.getCurrentFirst()-1);
        query.setPageSize(page.getPageSize());
        query.setLastRows(page.getCurrentLast());
        
        List<SysLog> result = sysLogDao.findPage(query);
        page.setResult(result);
                
        return page;
    }

    @Override
    public Integer saveOrUpdate(SysLog entity) throws ServiceException {
        if(entity.getId() == null){
            return sysLogDao.save(entity);
        } else {
            return sysLogDao.update(entity);
        }
    }
}
