package com.wzw.study.business.service;

import com.wzw.study.system.exception.ServiceException;
import com.wzw.study.system.service.BaseService;
import com.wzw.study.system.model.Page;
import com.wzw.study.business.model.BusWeb;
import com.wzw.study.business.query.BusWebQuery;

/*
 * 版    权:  Copyright©2019 Beijing Eternal Research Co.,Ltd. All Right Reserved.
 * 描    述:
 * 修 改 人:  ETRES
 * 修改时间:
 * 修改内容:  新版作成
*/
public interface BusWebService extends BaseService<BusWeb, BusWebQuery> {

    /**
     * 分页查询
     * @param page
     * @param query
     * @return
     */
    public Page<BusWeb> findPage(Page<BusWeb> page, BusWebQuery query) throws ServiceException;

    /**
     * 保存
     * @param entity
     * @throws ServiceException
     */
    public Integer saveOrUpdate(BusWeb entity) throws ServiceException;

}